<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT name,house_rented from active_tenants";
$result = mysqli_query($conn,$sql);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">
    <title>New House Unit</title>
   
</head>
<body>
  
    <div class="container mt-5">

    <a href="house.php" class="btn btn-danger float-end">BACK</a>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">

                        <?php
                        
                                ?>
                                <form action="answer.php" method="POST">
                                <div class="mb-3">
                                        <label>Month Of</label>
                                        <input type="date" name="rent_of"  class="form-control">
                                    </div>
                                <div class="mb-3">
                                        <label>Tenant</label>
                                        <select name="name" >
                                   <?php  while($row=mysqli_fetch_assoc($result))
                                     { ?>
        <option ><?php echo $row['name'],",",$row['house_rented'] ?></option>
        <?php
                                     }  
                                     
                                     ?>
                                    </select>
                                    </div>
                                <div class="mb-3">
                                        <label> Other Charges</label>
                                        <input type="text" name="other_charges"  class="form-control">
                                    </div>
                                <div class="mb-3">
                                        <label>Amount</label>
                                        <input type="text" name="amount"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <button type="submit" name="save_new" class="btn btn-primary">
                                            Save Unit
                                        </button>
                                        
                                    </div>

                                </form>
                                <?php
                            
                           
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>
</html>