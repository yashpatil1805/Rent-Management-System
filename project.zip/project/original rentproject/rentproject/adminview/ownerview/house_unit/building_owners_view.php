<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from building_owners";
$result = mysqli_query($conn,$sql);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Building Owners</title>
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">
</head>
<body>
<table class="center" border="2">
        <tr>
            <td>#</td> 
            <td>Name</td>
            <td>Phone</td>
            <td>Email</td>
            <td>Agent(%)</td>
            <td>Date Joined</td>
            <td>Agreement Date</td>
            <td>Status</td>
            <td>Passport Photo</td>
            <td>Agreement</td>
            <td colspan="3">Action</td>
        </tr>
    
                            <a href="building_owners.php" class="btn btn-danger float-end">BACK</a>
                    
                
                        <?php
                        if(isset($_GET['id']))
                        {
                            $b_id = mysqli_real_escape_string($conn, $_GET['id']);
                            $query = "SELECT * FROM building_owners WHERE id='$b_id' ";
                            $query_run = mysqli_query($conn, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $owner = mysqli_fetch_array($query_run);
                                ?>
                                <tr>
                
                                    <td><?= $owner["id"]?></td>
                                    <td><?= $owner["name"]?></td>
                                    <td><?= $owner["phone"]?></td>
                                    <td><?= $owner["email"]?></td>
                                    <td><?= $owner["agent_percent"]?></td>
                                    <td><?= $owner["date_joined"]?></td>
                                    <td><?= $owner["agreement_date"]?></td>
                                    <td><?= $owner["status"]?></td>
                                    <td><?= $owner["passport_photo"]?></td>
                                    <td><?= $owner["agreement"]?></td>
                                  
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                         </table>
   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>