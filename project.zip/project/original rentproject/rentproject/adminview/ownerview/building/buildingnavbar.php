
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide|Sofia|Trirong&effect=fire|neon|outline|emboss|shadow-multiple">
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">
</head> 
<body>
    <div class="mydash">
       <ul>
        <li>
        <p>
        <h2 class="font-effect-shadow-multiple">List Of Building.....</h2>
        </p>
        </li>
        <li>
        <a href="building_new.php"class="new" target="dashboard">New</a>
        </li>
       </ul> 

    </div>
    <div class="entries">
       <ul>
        <li>
    

        </li>
        <li class="search">
        <form action="search.php" method="POST" target="bos">
         Search: <input type="text" name="search">
        <a href="bos.php" target="bos">BACK</a>
       
      
        </form>
        </li>
       </ul> 

    </div>
   
    
        
</body>
</html>



