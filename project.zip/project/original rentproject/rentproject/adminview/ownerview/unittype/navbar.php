<?php 
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from building";
$result = mysqli_query($conn,$sql);
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide|Sofia|Trirong&effect=fire|neon|outline|emboss|shadow-multiple">
</head>
<style>
    div{
        background-color: antiquewhite;
        padding: 0px;
    }
    .view{
        margin-top: 150px;
        padding: 0px;
    }
    table{
        width: 1200px;
        height: 150px;

    }
    a{
        text-decoration: none;
    }
    td{
        text-align: center;

    }
    ul{
        display: flex;

    }
    li{
        list-style: none;

    }
    body{
        background-color:antiquewhite
    }
    .btn{
        margin-left: 0px;
    margin-top: 15px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .new{
        margin-left: 800px;
    margin-top: 20px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .search{
        margin-left: 840px;
    margin-top: 15px;
    }
    table.center
    {
        margin-left: auto;
        margin-right: auto;
    }
    
</style>
<body>
    <div class="mydash">
       <ul>
        <li>
        <p>
          
          <h2 class="font-effect-shadow-multiple">List of Units</h2>
        </p>
        </li>
       
       
        <li>
        <a href="new.php" target="dashboard" name="save_unit" class="new">New+</a>
        </li>
        </li>
       </ul> 

    </div>
    <div class="entries">
       <ul>
        <li>
        

        </li>
        <li class="search">
        <form action="search.php" method="POST" target="bos">
         Search: <input type="text" name="search">
        <a href="bos.php" target="bos">BACK</a>
       
      
        </form>
        </li>
       </ul> 

    </div>
   
    
        
</body>
</html>



