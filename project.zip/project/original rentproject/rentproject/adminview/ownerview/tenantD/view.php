<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from deposit_tenants";
$result = mysqli_query($conn,$sql);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">
    <title>Building Owners</title>
    </head>
<body>
<table class="center" border="2">
        <tr>
            <td>sno</td> 
            <td>Name</td>
            <td>date</td>
            <td>type</td>
            <td>house deposit</td>
            <td>water deposit</td>
            <td>Electricity deposit</td>
            <td>Total</td>
            <td>Description</td>
            <td>House rented</td>
        </tr>
    
                            <a href="building_owners.php" class="btn btn-danger float-end">BACK</a>
                    
                
                        <?php
                        if(isset($_GET['sno']))
                        {
                            $b_id = mysqli_real_escape_string($conn, $_GET['sno']);
                            $query = "SELECT * FROM deposit_tenants WHERE sno='$b_id' ";
                            $query_run = mysqli_query($conn, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $owner = mysqli_fetch_array($query_run);
                                ?>
                                <tr>
                
                                    <td><?= $owner["sno"]?></td>
                                    <td><?= $owner["name"]?></td>
                                    <td><?= $owner["date"]?></td>
                                    <td><?= $owner["type"]?></td>
                                    <td><?= $owner["house_deposit"]?></td>
                                    <td><?= $owner["water_deposit"]?></td>
                                    <td><?= $owner["electricity_deposit"]?></td>
                                    <td><?= $owner["total"]?></td>
                                    <td><?= $owner["description"]?></td>
                                    <td><?= $owner["house_rented"]?></td>
                                  
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                         </table>
   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>