<!DOCTYPE html>
<html>
<head>
    <title>Dynamic Countdown</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>

<h1>Countdown Timer</h1>
<div id="countdown"></div>

<script>
    // Function to update countdown
    function updateCountdown() {
        // Get the current date and time
        var now = new Date().getTime();

        // Set the countdown date (e.g., 1 hour from now)
        var countdownDate = <?php echo strtotime('+1 hour') * 1000; ?>;

        // Calculate the remaining time
        var distance = countdownDate - now;

        // Calculate time units
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Display the countdown
        document.getElementById("countdown").innerHTML = hours + "h "
        + minutes + "m " + seconds + "s ";

        // If the countdown is finished, display a message
        if (distance < 0) {
            clearInterval(interval);
            document.getElementById("countdown").innerHTML = "Countdown expired";
        }
    }

    // Update countdown every second
    var interval = setInterval(updateCountdown, 1000);

    // Initial call to display the countdown immediately
    updateCountdown();
</script>

</body>
</html>
