<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rent Management System</title>
    <style>
        body{
            background: linear-gradient(146deg, rgb(255 210 145) 24%, rgb(118 85 20) 63%);
    height: 605px;
    justify-content: center;
    margin-top: 80px;
    margin-left: 546px;
    overflow: hidden;
        }

        h1{
            /* font-size:40px; */
            font-family:verdana,sans-serif;
            text-align:center;
        }


        .loginbox{
            border:2px solid white;
            height: 460px;
            width:340px;
            background-color: white;
            border-radius: 8px;
            display: block;
            justify-content: center;
            padding: 30px;
        }

        .details{
            font-size:14px;
            font-family:Georgia,serif sans-serif;
        }


        input{
            width:320px;
            padding: 10px;
            border-radius:10px ;
            border:1px solid grey;
        }

        button{
            font-size:18px;
            font-family:sans-serif;
            border:1px solid white;
            background: linear-gradient(146deg, rgba(255 217 142) 24%, rgb(118 92 2) 63%);
            color:white;
            width:350px;
            height:37px;
        }
        #submit{
            font-size:18px;
            font-family:sans-serif;
            border:1px solid white;
            background: linear-gradient(146deg, rgba(255 217 142) 24%, rgb(118 92 2) 63%);
            color:white;
            width:350px;
            height:37px;

        }

        .bottom{
            font-size:9px;
            font-family:Arial,helvetica,sans-serif;
            color:black;
        }

        select{
            border:1px solid black;
            font-size:12px;
            padding: 10px;
            border-radius: 10px;
        }
        .loginas{

            display: flex;

        }
        
    </style>
</head>
<body>
    <br>
<div>
<?php include 'header.html';?>
</div>
<br>
<br>
    <div class="loginbox">
        
        <form action="check.php" method="POST">      
            <h1>LOGIN FORM</h1>
            <hr>
            <br><br>
           <div class="loginas"> 
            
            <!-- <input type="radio" name="f" value="admin">Admin -->
            <!-- <input type="radio" name="f" value="owner">Owner -->
            </div>
             <br>
            <div class="deatils">
                
                USERNAME: <br>
                <input type="text" name="username" placeholder="Enter your Username" minlength="6" required >
                <br><br>
                <?php
                session_start();
                
                if(isset($_SESSION['wrongps']) && isset($_SESSION['ctflag']))
                {
                    echo("You have Entered Wrong Password ".$_SESSION['wrongps']."times and You have to Wait until 30 Seconds to re-Enter.");
                    if((time()-$_SESSION['currenttime'])>30)
                    {
                       
                        unset($_SESSION['ctflag']);
                        unset($_SESSION['wrongps']);
                        session_destroy();
                    }
                    
                }
                else if(isset($_SESSION['wrongps']))
                {
                   
                    echo("You have Entered Wrong Password ".$_SESSION['wrongps']."times");
                    ?>
                    PASSWORD: <input type="password" name="password" placeholder="Enter your Password" minlength="6"required > 
                    <?php
                }
                else{
                    ?>
                    PASSWORD: <input type="password" name="password" placeholder="Enter your Password" minlength="6"required > 
                    <?php
                    
                }
            
                ?>
                <br>
                <?php
               
                if(isset($_SESSION['notfound']))
                {
                    echo ($_SESSION['notfound'])."<br><br>";
                    unset($_SESSION['notfound']);
                    
                } ?>
            </div>
            
            <p><a href="#">Forgot Password?</a></p>
            
            <br>
            <input id="submit" type="submit" value="LOGIN" name="submit">
           
            
    
        </form>

        <div class="bottom">
            <center>
                <br><br>
          <h3>  Dont have a account? <br> Signup as
            <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                <option value="select">Select Type</option>
                <option value="ownersignup.php">Owner</option>
                <option value="#">admin</option>
               
            </select>
            </center>
        </div>
        
        <br>
        <br>
    </div>
    <br><br>
    <div>
        <?php include 'footer.html';?>
    </div>
</body>
</html>
