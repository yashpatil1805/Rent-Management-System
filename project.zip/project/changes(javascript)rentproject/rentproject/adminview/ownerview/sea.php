<?php
    $num=$_POST['num'];
    $i=0;
    $j=0;
    $a=array(1,2,3,4);
    $b=array(5,6,7,8,9,10);
    $multi=array($a,$b);
    $x=count($multi);
    echo"$x";
    for($i=0;$i<count($multi);$i++)
    {
        for($j=0;$j<count($multi[$i]);$j++)
        {
            echo $multi[$i][$j];
            if($num==$multi[$i][$j])
            {
                echo "<br>$num found";
            }
        
            
        }
        
    }
    
    ?>