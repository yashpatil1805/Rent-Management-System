<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from building_owners";
$result = mysqli_query($conn,$sql);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Building Owners</title>
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">
</head>
<body>
<table class="center" border="2">
        <tr>
            <td>#</td> 
            <td>Name</td>
            <td>Type</td>
            <td>Building</td>
            <td>Floor</td>
            <td>Rent</td>
            <td colspan="3">Action</td>
        </tr>
    
                            <a href="house.php" class="btn btn-danger float-end">BACK</a>
                    
                
                        <?php
                        if(isset($_GET['sno']))
                        {
                            $b_id = mysqli_real_escape_string($conn, $_GET['sno']);
                            $query = "SELECT * FROM house_units WHERE sno='$b_id' ";
                            $query_run = mysqli_query($conn, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $owner = mysqli_fetch_array($query_run);
                                ?>
                                <tr>
                
                                    <td><?= $owner["sno"]?></td>
                                    <td><?= $owner["name_no"]?></td>
                                    <td><?= $owner["type"]?></td>
                                    <td><?= $owner["building"]?></td>
                                    <td><?= $owner["floor"]?></td>
                                    <td><?= $owner["rent"]?></td></tr>
                                  
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                         </table>
   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>