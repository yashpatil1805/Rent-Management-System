<?php
$cat=$_COOKIE['myname'];
echo "here is the name which was set in the cookie =$cat";
?>