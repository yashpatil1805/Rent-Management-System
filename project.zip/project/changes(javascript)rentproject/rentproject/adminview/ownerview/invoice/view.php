<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from payment";
$result = mysqli_query($conn,$sql);
$sql1="SELECT * from house_units";
$result1 = mysqli_query($conn,$sql1);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Invoice</title>
<style>
        body{
            background-color: antiquewhite;
        }
         div{
        /* background-color: antiquewhite; */
        padding: 0px;
    }
    .view{
        margin-top: 150px;
        padding: 0px;
    }
    table{
        width: 1200px;
        height: 150px;

    }
    .trial{
        /* background-color: chartreuse; */
        float:left;
    }
    a{
        text-decoration: none;
    }
    td{
        text-align: center;

    }
    ul{
        display: flex;

    }
    li{
        list-style: none;

    }
    .btn{
        margin-left: 0px;
    margin-top: 15px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .new{
        margin-left: 800px;
    margin-top: 20px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .search{
        margin-left: 840px;
    margin-top: 15px;
    }
    table.center
    {
        margin-left: auto;
        margin-right: auto;
    }
    .desc{
        /* background-color: aquamarine; */
        display: block;
    }
    .r1{
        position:absolute;
        right:450px;
        
        
        /* background-color: aqua; */
    }
    .r2{
        position:absolute;
        right:450px;
        
        
        /* background-color: aqua; */
    }
    .row1{
        display:flex;
    }
    .row2{
        display:flex;
    }
    .outer{
        background-image: linear-gradient(45deg,#c7beac, #a07600);
        border-radius: 20px;
        margin-left: 100px;
        margin-right: 400px;
        color: aliceblue;
    }
    
    </style>
</head>
    
<body>
    <div class="head">
    <h2>Swapnanagri House Apartments</h2>
    <h4>Mobile: 9545643446 / 9028663227</h4>
    <h4>Email: renthouse@gmail.com</h4> 
    <hr>
</div> 
<div class="outer">
<br><br>
    
    
                        <?php
                        $cnt=2;
                        $a=0;
                        if(isset($_GET['sno']))
                        {
                            $b_id = mysqli_real_escape_string($conn, $_GET['sno']);
                            $query = "SELECT * FROM payment WHERE sno='$b_id' ";
                            $query_run = mysqli_query($conn, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $owner = mysqli_fetch_array($query_run);
                                ?>
                                 <div class="row1">
                                 <div class="trial">
                                    To: <hr>
                                   <?php  while($row=mysqli_fetch_assoc($result))
                                     {
                                        if($row['sno']==$b_id)
                                        {
                                            $date=$row['date'];
                                            $xyz=strtok($row['tenant'],",");
                                            $xyz2=$xyz.",";
                                            $resStr = str_replace($xyz2,' ', $row['tenant']);
                                            $unit=strtok($resStr,",");
                                           // echo $unit;
                                            $unit = str_replace(' ','',$unit);
                                            
                                     ?>
                                    
        <?php  echo $xyz ."<br>".$resStr ?> <br> <?php echo $row['rent_of']."<br>" ?>
                                        <?php
                                     }  
                                    }
                                     ?>
                                     <br>
                                  </div>
                                <div class="r1">
                                    
    
                                        Invoice :INV-<?php echo $b_id ?>
                                      <br>Invoice Date : <?php echo $date ?> 
                                       
                                        
                                          
                                </div>
                                </div>
                                <br>
                                <div class="row2">
                                <div class="desc">
                                
                                    Description <hr>
                                   
                                Monthly House Rent <br>
                                Electricity fixed Bill <br>
                                Water Fixed Bill <br>
                                Garbage Collection Charges 
                                </div>
                                <div class="r2">
                                    
                                 <?php   

                              $i=0;
                                while($row1=mysqli_fetch_assoc($result1))
                                    {
                                        $yash = $row1['name_no'];
                                       
                                        if($yash==$unit)
                                         {
                                            
                                             ?> 
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Amount:<hr>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row1['rent'];?> <br>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row1['electricity_charges'];?> <br>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row1['water_charges'];?> <br>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row1['garbage_charges'];?><br>
                                            <hr> Total: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php 
                                            $total=$row1['rent']+$row1['electricity_charges']+$row1['water_charges']+ $row1['garbage_charges'];
                                            echo $total?>
                                        <?php
                                        }
                                    }



                             ?>
                                </div>
                                </div>
                               <?php
                              
                        }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                         </table>
   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</div>
</body>
</html>