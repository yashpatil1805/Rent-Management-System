<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql2="SELECT * from vacated_tenants";
$result2 = mysqli_query($conn,$sql2);
$sql="SELECT name from active_tenants";
$result = mysqli_query($conn,$sql);
$sql1="SELECT name_no,building from house_units";
$result1 = mysqli_query($conn,$sql1);
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Edit House Unit</title>
   
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">
</head>
<body>
  
    <div class="container mt-5">

       

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4> Edit Deposit Tenants
                            <a href="vacated.php" class="btn btn-danger float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <?php
                      /*  $b=$_GET['sno'];
                        echo $b;*/
                     if(isset($_GET['sno']))
                     {
                         $b_id = mysqli_real_escape_string($conn, $_GET['sno']);
                         $query = "SELECT * FROM vacated_tenants WHERE sno='$b_id' ";
                         $query_run = mysqli_query($conn, $query);
                    /*    $a=mysqli_num_rows($query_run);
                        echo $a;*/
                         if(mysqli_num_rows($query_run) > 0)
                         {
                             $depo = mysqli_fetch_array($query_run);
                             ?>
                             <form action="answer.php" method="POST">
                                  <input type="hidden" name="sno" value="<?= $depo['sno']; ?>">
                            
                                  <div class="mb-3">
                                        <label>Tenant  Name</label>
                                        <select name="name" >
                                   <?php  while($row=mysqli_fetch_assoc($result))
                                     { $row1=mysqli_fetch_assoc($result1)
                                        ?>
        <option name="nameid" value="<?= $row['name'].",".$row1['name_no'].",".$row1["building"] ?>"><?php echo $row['name'].",".$row1['name_no'].",".$row1["building"] ?></option>
        
        <?php
                                     }  
                                     ?>
                                  
                                    </select>
                                    </div>
                                    <div class="mb-3">
                                        <label>Date of Vacation</label>
                                        <input type="date" name="date_vacated"  value="<?= $depo['date_vacated']; ?>" class="form-control">
                                    </div>
                                <div class="mb-3">
                                        <label>House of Condition</label>
                                        <input type="text" name="house_condition"  value="<?= $depo['house_condition']; ?>" class="form-control">
                                    </div>

                                    
                                 <div class="mb-3">
                                     <button type="submit" name="update_deposit" class="btn btn-primary">
                                         Save
                                     </button>
                                     
                                 </div>

                             </form>
                               
                        <?php
                         }
                          ?> 
                             <?php
                         }
                         else
                         {
                             echo "<h4>No Such Id Found</h4>";
                         }
                     
                     ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>