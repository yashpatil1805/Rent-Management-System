<?php
 $conn=mysqli_connect("localhost","root","","rentdb");
 $sql="SELECT * from vacated_tenants";
 $result = mysqli_query($conn,$sql);
 ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide|Sofia|Trirong&effect=fire|neon|outline|emboss|shadow-multiple">
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">
    <style>
        .new{
        background-image: linear-gradient(45deg,#d7af87,white);
        }
    </style>
  </head>

<body>
    <div class="mydash">
       <ul>
        <li>
       
<h2 class="font-effect-shadow-multiple">Previous Tenants</h2>
        </li>
        <li>
        <a href="newpage.php" target="dashboard" name="save_unit" class="new">New+</a>
        </li>
       </ul> 

    </div>
    <div class="entries">
       <ul>
        <li>
          


        </li>
        <li class="search">
      <div class="back">  <a href="bos.php" target="bos"> BACK</a></div>
        <form action="search.php" target="bos" method="POST">
        
         Search: <input type="text" name="search">
        
        
       
      
        </form>
        </li>
       </ul> 

    </div>

       
    </table>
</body>
</html>
