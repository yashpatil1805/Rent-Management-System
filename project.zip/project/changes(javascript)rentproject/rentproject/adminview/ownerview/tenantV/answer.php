<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql1='SELECT * FROM vacated_tenants';
$result1=mysqli_query($conn,$sql1);

if(isset($_POST['delete_unit']))
{
    $id = mysqli_real_escape_string($conn, $_POST['delete_unit']);
    $num=$id;
    $query = "DELETE FROM vacated_tenants WHERE sno='$id' ";

    $query_run = mysqli_query($conn, $query);
  
    while($row=$result1->fetch_assoc())
    {
        $q="UPDATE `vacated_tenants` SET `sno` = '$num' WHERE `vacated_tenants`.`sno` = $num+1";
        $k= mysqli_query($conn,$q);
        $num++;
    }

    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: bos.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: bos.php");
        exit(0);
    }
}

if(isset($_POST['update_deposit']))
{
    $id = mysqli_real_escape_string($conn, $_POST['sno']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $namey=strtok($name,",");
    $sql="SELECT phone,house_rented,date_occupied FROM active_tenants where name='$namey'";
    $result = mysqli_query($conn,$sql);
    while($row=mysqli_fetch_assoc($result))
    {
        $house_rented = $row['house_rented'];
        $phone = $row['phone'];
        $date_occupied = $row['date_occupied'];
    }
    $sno = mysqli_num_rows($result1);
    $sno++;
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $date_vacated = mysqli_real_escape_string($conn, $_POST['date_vacated']);
    $house_condition=mysqli_real_escape_string($conn, $_POST['house_condition']);
  
    $query = "UPDATE vacated_tenants SET name='$name',house_rented='$house_rented',phone='$phone',date_occupied='$date_occupied',date_vacated='$date_vacated',house_condition='$house_condition' WHERE sno='$id'";
    $query_run = mysqli_query($conn, $query);

  if($query_run)
    {
        $_SESSION['message'] = "Owners Updated Successfully";
        header("Location: vacated.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Owners Not Updated";
        header("Location: deposit.php");
        exit(0);
    }

}

/*
if(isset($_POST['save_student']))
{
    
    $sno = mysqli_num_rows($result);
    $sno++;
    $name_no = mysqli_real_escape_string($conn, $_POST['name_no']);
    $type = mysqli_real_escape_string($conn, $_POST['type']);
    $building = mysqli_real_escape_string($conn, $_POST['building']);
    $floor = mysqli_real_escape_string($conn, $_POST['floor']);
    $rent = mysqli_real_escape_string($conn, $_POST['rent']);
    $electricity_charges = mysqli_real_escape_string($conn, $_POST['electricity_charges']);
    $water_charges = mysqli_real_escape_string($conn, $_POST['water_charges']);
    $garbage_charges = mysqli_real_escape_string($conn, $_POST['garbage_charges']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

   $query = "INSERT INTO house_units (sno,name_no,type,building,floor,rent,electricity_charges,water_charges,garbage_charges,description,status) VALUES ('$sno',$name_no','$type',' $building',' $floor','$rent','$electricity_charges','$water_charges','$garbage_charges','$description','$status')";
  //$query = "  INSERT INTO `house_units` (`sno`, `name_no`, `type`, `building`, `floor`, `rent`, `electricity_charges`, `water_charges`, `garbage_charges`, `description`, `status`) VALUES ('$sno',$name_no','$type',' $building',' $floor','$rent','$electricity_charges','$water_charges','$garbage_charges','$description','$status')";
//INSERT INTO `house_units` (`sno`, `name_no`, `type`, `building`, `floor`, `rent`, `electricity_charges`, `water_charges`, `garbage_charges`, `description`, `status`) VALUES ('3', 'indira', 'multiStorey', 'Dhruv', '4', '10000', '200', '299', '0', 'nikal lode', 'Bhadva hai');
    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: house.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: house.php");
        exit(0);
    }
}*/
if(isset($_POST['save_new']))
{
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $namey=strtok($name,",");
    $sql="SELECT phone,house_rented,date_occupied FROM active_tenants where name='$namey'";
    $result = mysqli_query($conn,$sql);
    while($row=mysqli_fetch_assoc($result))
    {
        $house_rented = $row['house_rented'];
        $phone = $row['phone'];
        $date_occupied = $row['date_occupied'];
    }
    $sno = mysqli_num_rows($result1);
    $sno++;
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $date_vacated = mysqli_real_escape_string($conn, $_POST['date_vacated']);
    $house_condition=mysqli_real_escape_string($conn, $_POST['house_condition']);

   // $id = mysqli_real_escape_string($conn, $_POST['id']);
  //  $name = mysqli_real_escape_string($conn, $_POST['building_name']);
   // $floors = mysqli_real_escape_string($conn, $_POST['floor']);
 //   $rent = mysqli_real_escape_string($conn, $_POST['rent']);
   // $electricity_charges = mysqli_real_escape_string($conn, $_POST['electricity_charges']);
  /*  $owner = mysqli_real_escape_string($conn, $_POST['owner']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);*/
    $query = "INSERT INTO vacated_tenants (sno,name,phone,house_rented,date_occupied,date_vacated,house_condition) VALUES ('$sno','$name','$phone','$house_rented','$date_occupied','$date_vacated','$house_condition')";

    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: vacated.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: vacated.php");
        exit(0);
    }
}


?>
