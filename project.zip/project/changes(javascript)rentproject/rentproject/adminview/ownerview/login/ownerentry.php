
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<?php
session_start();
            $conn=mysqli_connect("localhost","root","","rentdb");
            $sql="SELECT * from ownerlogin";
            $result = mysqli_query($conn,$sql);
           
if(isset($_POST['submit']))
{
    
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);
    if($password!=$confirm_password)
    {
        $_SESSION['passwordnotmatch'] = "The Password you Entered Doesn't Match";
        header("Location: ownersignup.php");
        exit(0);
    }
    $name = mysqli_real_escape_string($conn, $_POST['name']);
     $email = mysqli_real_escape_string($conn, $_POST['email']);
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
    $query = "INSERT INTO ownerlogin (username,password,name,email,mobile_no) VALUES ('$username','$password','$name','$email','$mobile')";
    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: ownersignup.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Owner Not Created";
        header("Location: ownersignup.php");
        exit(0);
    }
}



?>
</body>
</html>



