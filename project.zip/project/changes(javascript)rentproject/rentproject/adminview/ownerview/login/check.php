
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<?php
session_start();
            $conn=mysqli_connect("localhost","root","","rentdb");
            $sql="SELECT * from ownerlogin";
            $result = mysqli_query($conn,$sql);
            // $sql1="SELECT * from studentsignup";
            // $result1 = mysqli_query($conn,$sql1);
           
if(isset($_POST['submit']))
{
    $choice=    mysqli_real_escape_string($conn, $_POST['f']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $count=0;
    if($choice=="owner")
    {
        while($row=$result->fetch_assoc())
        {
    
            if($row['password']==$password and $row['username']==$username)
            {
              /*  $_SESSION['message'] = "User Logged in Successfully";
                header("Location: login.php");
                exit(0);*/
                    header("Location: ../home.html");
                    $count=1;
                    die();
            }
            
         }
         if($count==0){
            $_SESSION['notfound'] = "Invalid Entry";
            header("Location: loginmain.php");
            exit(0);
        }

    }
    // else{
    //     while($row1=$result1->fetch_assoc())
    //     {
    
    //         if($row1['password']==$password and $row1['username']==$username)
    //         {
    //           /*  $_SESSION['message'] = "User Logged in Successfully";
    //             header("Location: login.php");
    //             exit(0);*/
    //                 header("Location: studentview.php");
    //                 $count=1;
    //                 die();
    //         }
    //      }
    //      if($count==0){
    //         $_SESSION['notfound'] = "Invalid Entry";
    //         header("Location: loginmain.php");
    //         exit(0);
    //     }

    // }
   
    }




?>
</body>
</html>



