<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Hub</title>
    <style>
          body{
            background: linear-gradient(153deg, rgba(203,141,33,1) 35%, rgba(212,24,135,1) 63%);
            height:605px;
            display: flex;
            justify-content: center;
            margin-top: 80px; 
        }

        
        .loginbox{
            border:2px solid white;
            height: auto;
            width:auto;
            background-color: white;
            border-radius: 8px;
            display: block;
            justify-content: center;
            padding: 30px;
            margin-bottom: auto;
         
        }

        h1{
            font-family: verdana,sans-serif;
            text-align: center;
            font-size: 24px;
        }

        .details{
            font-size:14px;
            font-family:Georgia,serif sans-serif;
        }
        
        input{
            width: 190px;
            padding: 10px;
            border-radius:10px ;
            border:1px solid grey;
           
        }

        .bottom{
            text-align: center;
            font-size:11px;
            font-family:Arial,helvetica,sans-serif;
            color:red;
        }

        button{
            font-size:18px;
            font-family:sans-serif;
            border:1px solid white;
            background: linear-gradient(153deg, rgba(203,141,33,1) 35%, rgba(212,24,135,1) 63%);
            color:white;
            width:470px;
            height:37px;  
        }

    </style>
</head>
<body>

    
    <div class="loginbox">
       <center> <form action="facultyentry.php" method="POST">
           FACULTY SIGNUP/REGISTER <br><br>
</center>
            USERNAME: <input type="text" name="username" placeholder="Create your Username" minlength="6" >
            <br><br>
           
            SET PASSWORD: <input type="password" name="password" placeholder="Set your Password" minlength="6" > <br><br>
            CONFIRM PASSWORD: <input type="password" name="confirmpassword" placeholder="Confirm your Password" minlength="6" > <br><br>
            <?php
session_start();
if(isset($_SESSION['passwordnotmatch']))
{
    echo ($_SESSION['passwordnotmatch'])."<br><br>";
    unset($_SESSION['passwordnotmatch']);
    
}
    ?>
            AISHE CODE: <input type="text" name="aishecode" placeholder="Enter the AISHE CODE" minlength="6" >
            <br><br>
            COLLEGE NAME: <input type="text" name="collegename" placeholder="Enter the COllege Name" minlength="6" >
            <br><br>
            COLLEGE FACULTY NAME: <input type="text" name="facultyname" placeholder="Enter Faculty Name" minlength="6" >
            <br><br>
            EMAIL: <input type="text" name="email" placeholder="Enter Email ID" minlength="6" >
            <br><br>
            MOBILE NO: <input type="text" name="mobile" placeholder="Enter Mobile No:" minlength="6" >
            <br>
            <br>
            * Disclaimer: Do check the mobile number and email ID<br> as they will be used for all future communication and verification.
            <br>
         <center>   <br><input type="submit" name="submit" value="Submit"></center> 

        </form>
        <?php

    if(isset($_SESSION['message']))
    {
        echo "<h3>".($_SESSION['message'])."<h3>";
        unset($_SESSION['message']);
    }
    ?>
    </div>
    

    
</body>
</html>