<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from deposit_tenants";
$result = mysqli_query($conn,$sql);

if(isset($_POST['delete_unit']))
{
    $id = mysqli_real_escape_string($conn, $_POST['delete_unit']);
    $num=$id;
    $query = "DELETE FROM deposit_tenants WHERE sno='$id' ";

    $query_run = mysqli_query($conn, $query);
  
    while($row=$result->fetch_assoc())
    {
        $q="UPDATE `deposit_tenants` SET `sno` = '$num' WHERE `deposit_tenants`.`sno` = $num+1";
        $k= mysqli_query($conn,$q);
        $num++;
    }

    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: bos.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: bos.php");
        exit(0);
    }
}

if(isset($_POST['update_deposit']))
{

    $id = mysqli_real_escape_string($conn, $_POST['sno']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $type = mysqli_real_escape_string($conn, $_POST['type']);
    $house_deposit = mysqli_real_escape_string($conn, $_POST['house_deposit']);
    $electricity_deposit = mysqli_real_escape_string($conn, $_POST['electricity_deposit']);
    $water_deposit = mysqli_real_escape_string($conn, $_POST['water_deposit']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $total=$water_deposit+$electricity_deposit+$house_deposit;
  
    $query = "UPDATE deposit_tenants SET name='$name',type='$type',house_deposit='$house_deposit',water_deposit='$water_deposit',electricity_deposit='$electricity_deposit',description='$description',total='$total' WHERE sno='$id'";
    $query_run = mysqli_query($conn, $query);

  if($query_run)
    {
        $_SESSION['message'] = "Owners Updated Successfully";
        header("Location: deposit.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Owners Not Updated";
        header("Location: deposit.php");
        exit(0);
    }

}

/*
if(isset($_POST['save_student']))
{
    
    $sno = mysqli_num_rows($result);
    $sno++;
    $name_no = mysqli_real_escape_string($conn, $_POST['name_no']);
    $type = mysqli_real_escape_string($conn, $_POST['type']);
    $building = mysqli_real_escape_string($conn, $_POST['building']);
    $floor = mysqli_real_escape_string($conn, $_POST['floor']);
    $rent = mysqli_real_escape_string($conn, $_POST['rent']);
    $electricity_charges = mysqli_real_escape_string($conn, $_POST['electricity_charges']);
    $water_charges = mysqli_real_escape_string($conn, $_POST['water_charges']);
    $garbage_charges = mysqli_real_escape_string($conn, $_POST['garbage_charges']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

   $query = "INSERT INTO house_units (sno,name_no,type,building,floor,rent,electricity_charges,water_charges,garbage_charges,description,status) VALUES ('$sno',$name_no','$type',' $building',' $floor','$rent','$electricity_charges','$water_charges','$garbage_charges','$description','$status')";
  //$query = "  INSERT INTO `house_units` (`sno`, `name_no`, `type`, `building`, `floor`, `rent`, `electricity_charges`, `water_charges`, `garbage_charges`, `description`, `status`) VALUES ('$sno',$name_no','$type',' $building',' $floor','$rent','$electricity_charges','$water_charges','$garbage_charges','$description','$status')";
//INSERT INTO `house_units` (`sno`, `name_no`, `type`, `building`, `floor`, `rent`, `electricity_charges`, `water_charges`, `garbage_charges`, `description`, `status`) VALUES ('3', 'indira', 'multiStorey', 'Dhruv', '4', '10000', '200', '299', '0', 'nikal lode', 'Bhadva hai');
    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: house.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: house.php");
        exit(0);
    }
}*/
if(isset($_POST['save_new']))
{
  $sno = mysqli_num_rows($result);
    $sno++;
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $type = mysqli_real_escape_string($conn, $_POST['type']);
    $house_deposit = mysqli_real_escape_string($conn, $_POST['house_deposit']);
    $electricity_deposit = mysqli_real_escape_string($conn, $_POST['electricity_deposit']);
    $water_deposit = mysqli_real_escape_string($conn, $_POST['water_deposit']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $total=$water_deposit+$electricity_deposit+$house_deposit;
   

   // $id = mysqli_real_escape_string($conn, $_POST['id']);
  //  $name = mysqli_real_escape_string($conn, $_POST['building_name']);
   // $floors = mysqli_real_escape_string($conn, $_POST['floor']);
 //   $rent = mysqli_real_escape_string($conn, $_POST['rent']);
   // $electricity_charges = mysqli_real_escape_string($conn, $_POST['electricity_charges']);
  /*  $owner = mysqli_real_escape_string($conn, $_POST['owner']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);*/
    $query = "INSERT INTO deposit_tenants (sno,name,type,house_deposit,electricity_deposit,water_deposit,description,date,total) VALUES ('$sno','$name','$type','$house_deposit','$electricity_deposit','$water_deposit','$description','$date','$total')";

    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: deposit.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: deposit.php");
        exit(0);
    }
}


?>
