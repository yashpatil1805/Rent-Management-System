
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<style>
     body{
        background-color: antiquewhite;
    }
    
    div{
        background-color: lightcyan;
        padding: 0px;
    }
    .view{
        margin-top: 150px;
        padding: 0px;
    }
    table{
        width: 1200px;
        height: 150px;
    }
    ul{
        display: flex;

    }
    li{
        list-style: none;

    }
    .add{
        margin-left: 840px;
    margin-top: 15px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .search{
        margin-left: 840px;
    margin-top: 15px;
    }
   
</style>
<body>
   
    <table  border="2">
        <tr>
            <td>sno</td> 
            <td>Name</td>
            <td>Building and Owner</td>
        </tr>
        <?php
      /*  $key=$_POST["search"];
    
        $conn=mysqli_connect("localhost","root","","rentdb");
        $sql="SELECT * from building_owners";
        $result=mysqli_query($conn,$sql);

    
            while($row=mysqli_fetch_assoc($result))
            {
                if($key == ($row['id'] or $row['name']))
               {
                    echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
                }
                else{
                    echo "person not found";
                }
            }*/
        /*    $uid=$_POST['search'];
            $conn=mysqli_connect("localhost","root","","rentdb");
            $sql="SELECT * from building_owners";
            $result = mysqli_query($conn,$sql);
            while($row=mysqli_fetch_assoc($result))
            {
                if($uid == $row['id'])
                {
                    echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
                }
            } */
            
        //   while($row=$result->fetch_assoc()){
          //      echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
              
          //}
        /*  <select name="building">

                                    <?php foreach ($building as $temp) : ?>
        <option ><?php echo $temp['building_name']; ?> </option>
    <?php endforeach; ?>
</select>*/
          
          $uid=$_POST['search'];
            $conn=mysqli_connect("localhost","root","","rentdb");
            $sql="SELECT * from unittype";
            $result = mysqli_query($conn,$sql);
            $a=false;
            while($row=mysqli_fetch_assoc($result))
            {
                if((stripos("$row[sno]","$uid")!==$a) or (stripos("$row[buildingname]","$uid")!==$a))
                {
                    ?>
                    <td><?= $row["sno"]?></td>
         <td><?= $row["type"]?></td>
         <td><?= $row["buildingname"]?></td>
         </form></td></tr>
                                             <?php
                }
            }   
        
        ?>
       
    </table>
</body>
</html>
