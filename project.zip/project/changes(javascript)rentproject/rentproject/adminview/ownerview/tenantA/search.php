
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">
</head>
<body>
   
    <table  border="2">
        
        <?php
    
          $uid=$_POST['search'];
            $conn=mysqli_connect("localhost","root","","rentdb");
            $sql="SELECT * from active_tenants";
            $result = mysqli_query($conn,$sql);
            $cnt=0;
            $success=0;
            $n=mysqli_num_rows($result) ;
            $a=false;
                
            while($row=mysqli_fetch_assoc($result)){ 
                if((stripos("$row[name]","$uid")!==$a)or(stripos("$row[id_no]","$uid")!==$a))
                {
                    if($success==0)
                    {
                        echo " <tr>
                        <td>#</td> 
                        <td>Name</td>
                        <td>Id</td>
                        <td>Phone</td>
                        <td>House Rented</td>
                        <td>Date Occupied</td>
                        <td>Last Payment</td>
                    </tr>";
                        $success++;
                    }
                
                    echo " <tr>
                    <td>".$row["sno"]."</td>
                    <td>".$row["name"]."</td>
                    <td>".$row["id_no"]."</td>
                    <td>".$row["phone"]."</td>
                    <td>".$row["house_rented"]."</td>
                    <td>".$row["date_occupied"]."</td>
                    <td>".$row["last_payment"]."</td>
                   </tr>";
                } 
                else
                {
                    $cnt++;
               }
        } 

        if($cnt==$n)
        {
            echo"<center><h1>Search was Unsuccessful</h1></center>";
        }
      ?>
       
    </table>
      </body>
      </html>