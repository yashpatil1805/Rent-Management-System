<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from active_tenants";
$result = mysqli_query($conn,$sql);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">
    <title>Building Owners</title>
   </head>
<body>
<table class="center" border="2">
        <tr>
            <td>#</td> 
            <td>Name</td>
            <td>Phone</td>
            <td>House_Rented</td>
            <td>Type</td>
            <td>Floor</td>
            <td>Date Occupied</td>
            <td>Last_payment</td>
            <td>Status</td>
            <td>Id No</td>
            <td>Email</td>
            <td>Download Photo</td>
            <td>Agreement Document</td>

        </tr>
    
                            <a href="active.php" class="btn btn-danger float-end">BACK</a>
                    
                
                        <?php
                        if(isset($_GET['sno']))
                        {
                            $b_id = mysqli_real_escape_string($conn, $_GET['sno']);
                            $query = "SELECT * FROM active_tenants WHERE sno='$b_id' ";
                            $query_run = mysqli_query($conn, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $owner = mysqli_fetch_array($query_run);
                                ?>
                                <tr>
                
                                    <td><?= $owner["sno"]?></td>
                                    <td><?= $owner["name"]?></td>
                                    <td><?= $owner["phone"]?></td>
                                    <td><?= $owner["house_rented"]?></td>
                                    <td><?= $owner["type"]?></td>
                                    <td><?= $owner["floor"]?></td>
                                    <td><?= $owner["date_occupied"]?></td>
                                    <td><?= $owner["last_payment"]?></td>
                                    <td><?= $owner["status"]?></td>
                                    <td><?= $owner["id_no"]?></td>
                                    <td><?= $owner["email"]?></td>
                                    <td><?= $owner["download_photo"]?></td>
                                    <td><?= $owner["agreement_doc"]?></td>
                                  
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                         </table>
   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>