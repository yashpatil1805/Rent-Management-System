<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from active_tenants";
$result = mysqli_query($conn,$sql);

if(isset($_POST['delete_unit']))
{
    $id = mysqli_real_escape_string($conn, $_POST['delete_unit']);
    $num=$id;
    $query = "DELETE FROM active_tenants WHERE sno='$id' ";

    $query_run = mysqli_query($conn, $query);
  
    while($row=$result->fetch_assoc())
    {
        $q="UPDATE `active_tenants` SET `sno` = '$num' WHERE `active_tenants`.`sno` = $num+1";
        $k= mysqli_query($conn,$q);
        $num++;
    }

    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: bos.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: bos.php");
        exit(0);
    }
}

if(isset($_POST['update']))
{

    $id = mysqli_real_escape_string($conn, $_POST['sno']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $house_rented = mysqli_real_escape_string($conn, $_POST['house_rented']);
    $date_occupied = mysqli_real_escape_string($conn, $_POST['date_occupied']);
    $id_no = mysqli_real_escape_string($conn, $_POST['id_no']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $download_photo = mysqli_real_escape_string($conn, $_POST['download_photo']);
    $agreement_doc = mysqli_real_escape_string($conn, $_POST['agreement_doc']);
  

    $query = "UPDATE active_tenants SET name='$name',phone='$phone',house_rented='$house_rented',date_occupied='$date_occupied',id_no='$id_no',email='$email',download_photo='$download_photo',agreement_doc='$agreement_doc' WHERE sno='$id'";
    $query_run = mysqli_query($conn, $query);

  if($query_run)
    {
        $_SESSION['message'] = "Owners Updated Successfully";
        header("Location: active.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Owners Not Updated";
        header("Location: active.php");
        exit(0);
    }

}



if(isset($_POST['save_new']))
{
  $sno = mysqli_num_rows($result);
    $sno++;
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $house_rented = mysqli_real_escape_string($conn, $_POST['house_rented']);
    $house = strtok($house_rented,",");
    $type = strtok($house_rented,",");
    $type = strtok(",");
    $building =  strtok($house_rented,",");
    $building =  strtok(",");
    $building =  strtok(",");
    $floor = strtok($house_rented,",");
    $floor = strtok(",");
    $floor = strtok(",");
    $floor = strtok(",");
    $floor = strtok(",");
    $floor = strtok(",");
    $ownerid = strtok($house_rented,",");
    $ownerid = strtok(",");
    $ownerid = strtok(",");
    $ownerid = strtok(",");
    $buildingid = strtok($house_rented,",");
    $buildingid = strtok(",");
    $buildingid = strtok(",");
    $buildingid = strtok(",");
    $buildingid = strtok(",");
    
    

    $date_occupied = mysqli_real_escape_string($conn, $_POST['date_occupied']);
    $id_no = mysqli_real_escape_string($conn, $_POST['id_no']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $download_photo = mysqli_real_escape_string($conn, $_POST['download_photo']);
    $agreement_doc = mysqli_real_escape_string($conn, $_POST['agreement_doc']);
  
  $query = "INSERT INTO active_tenants (sno,name,phone,house_rented,type,floor,date_occupied,id_no,email,download_photo,agreement_doc,building,ownerid,buildingid) VALUES ('$sno','$name','$phone','$house','$type','$floor','$date_occupied','$id_no','$email','$download_photo','$agreement_doc','$building','$ownerid','$buildingid')";

    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: active.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: active.php");
        exit(0);
    }
}


?>
