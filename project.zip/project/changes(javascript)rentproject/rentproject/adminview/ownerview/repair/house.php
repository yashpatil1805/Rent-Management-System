
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title></title>
</head>
   
    

    <frameset rows="30%,*" frameborder="NO" framespacing="0"  scrolling="NO">
		<frame src="navbar2.php" name="navbar"  noresize="noresize" border="0" scrolling="NO">
		</frame>
   
    
        <frame src="bos2.php" name="bos" noresize="noresize" border="0"
		</frame>

	</frameset>
</html>
