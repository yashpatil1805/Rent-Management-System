<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql='SELECT * from house_units';
$result=mysqli_query($conn,$sql);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>New House Repair</title>
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">    
</head>
<body>
  
    <div class="container mt-5">

    <a href="house.php" class="btn btn-danger float-end">BACK</a>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">

                        <?php
                        
                                ?>
                                <form action="insert.php" method="POST">
                                <div class="mb-3">
                                     <label>Unit name</label>
                                     <select name="name_no" >
                                   <?php  while($row=mysqli_fetch_assoc($result))
                                     { ?>
        <option ><?php echo $row['name_no'].",".$row['building'] ?></option>
        <?php
                                     }  
                                     ?>
                                    </select>    </div>
                                    <div class="mb-3">
                                     <label>Tenants to be changed</label>
                                     <input type="text" name="tt" class="form-control">
                                     </div>
                                    <div class="mb-3">
                                        <label>Date</label>
                                        <input type="date" name="date"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Total cost</label>
                                        <input type="text" name="cost"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Description</label>
                                        <input type="text" name="description"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <button type="submit" name="save_unit" class="btn btn-primary">
                                            Save 
                                        </button>
                                        
                                    </div>

                                </form>
                                <?php
                            
                           
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>
</html>