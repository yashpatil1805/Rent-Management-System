<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from building_owners";
$result = mysqli_query($conn,$sql);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">
    <title>Building Owners</title>
    </head>
<body>
<table class="center" border="2">
        <tr>
            <td>sno</td> 
            <td>Unit Name</td>
            <td>Description</td>
            <td>Total Cost</td>
            <td>Date</td>
            
            <td colspan="3">Action</td>
        </tr>
    
                            <a href="house.php" class="btn btn-danger float-end">BACK</a>
                    
                
                        <?php
                        if(isset($_GET['sno']))
                        {
                            $b_id = mysqli_real_escape_string($conn, $_GET['sno']);
                            $query = "SELECT * FROM house_repairs WHERE sno='$b_id' ";
                            $query_run = mysqli_query($conn, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $owner = mysqli_fetch_array($query_run);
                                ?>
                                <tr>
                
                                    <td><?= $owner["sno"]?></td>
                                    <td><?= $owner["unit_name"]?></td>
                                    <td><?= $owner["description"]?></td>
                                    <td><?= $owner["total_cost"]?></td>
                                    <td><?= $owner["date"]?></td>
                                    
                                  
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                         </table>
   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>