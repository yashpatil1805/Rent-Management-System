<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from house_repairs";
$result = mysqli_query($conn,$sql);

if(isset($_POST['delete_unit']))
{
    $id = mysqli_real_escape_string($conn, $_POST['delete_unit']);
    $num=$id;
    $query = "DELETE FROM house_repairs WHERE sno='$id' ";

    $query_run = mysqli_query($conn, $query);
  
    while($row=$result->fetch_assoc())
    {
        $q="UPDATE `house_repairs` SET `sno` = '$num' WHERE `house_repairs`.`sno` = $num+1";
        $k= mysqli_query($conn,$q);
        $num++;
    }

    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: bos2.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: bos2.php");
        exit(0);
    }
}

if(isset($_POST['update_rec']))
{
  $id = mysqli_real_escape_string($conn, $_POST['sno']);
  $name_no = mysqli_real_escape_string($conn, $_POST['name_no']);
  $tt=mysqli_real_escape_string($conn, $_POST['tt']);
  $date = mysqli_real_escape_string($conn, $_POST['date']);
  $total = mysqli_real_escape_string($conn, $_POST['cost']);
  $des = mysqli_real_escape_string($conn, $_POST['description']);

    $query = "UPDATE house_repairs SET unit_name='$name_no',description='$des',total_cost='$total',date='$date',tenant_to_be_charged='$tt' WHERE sno='$id'";
    $query_run = mysqli_query($conn, $query);

  if($query_run)
    {
        $_SESSION['message'] = "Owners Updated Successfully";
        header("Location: house.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Owners Not Updated";
        header("Location: house.php");
        exit(0);
    }

}

if(isset($_POST['save_unit']))
{
  $sno = mysqli_num_rows($result);
    $sno++;
    $name_no = mysqli_real_escape_string($conn, $_POST['name_no']);
    $name = strtok($name_no,",");
    $building=strtok($name_no,",");
    $building=strtok(",");
    $buildingid=strtok($name_no,",");
    $buildingid=strtok(",");
    $buildingid=strtok(",");
    $owner_id=strtok($name_no,",");
    $owner_id=strtok(",");
    $owner_id=strtok(",");
    $owner_id=strtok(",");
    
    $tt=mysqli_real_escape_string($conn, $_POST['tt']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $total = mysqli_real_escape_string($conn, $_POST['cost']);
    $des = mysqli_real_escape_string($conn, $_POST['description']);

   // $id = mysqli_real_escape_string($conn, $_POST['id']);
  //  $name = mysqli_real_escape_string($conn, $_POST['building_name']);
   // $floors = mysqli_real_escape_string($conn, $_POST['floor']);
 //   $rent = mysqli_real_escape_string($conn, $_POST['rent']);
   // $electricity_charges = mysqli_real_escape_string($conn, $_POST['electricity_charges']);
  /*  $owner = mysqli_real_escape_string($conn, $_POST['owner']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);*/
    $query = "INSERT INTO house_repairs (sno,unit_name,description,total_cost,date,tenant_to_be_charged,building,ownerid,buildingid) VALUES ('$sno','$name','$des','$total','$date','$tt','$building','$owner_id','$buildingid')";

    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: house.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: house.php");
        exit(0);
    }
}


?>
