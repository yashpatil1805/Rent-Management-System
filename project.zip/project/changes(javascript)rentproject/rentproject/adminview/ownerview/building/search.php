
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">
</head>

    <body>
   
    <table class="center" border="2">
        <tr>
            <td>#</td> 
            <td>Building Name</td>
            <td>Floors</td>
            <td>Owner</td>
            <td>Location</td>
            <td colspan="2">Action</td>
            </tr>
            <?php
             $uid=$_POST['search'];  
        $conn=mysqli_connect("localhost","root","","rentdb");
        $sql="SELECT * FROM building";
        $result = mysqli_query($conn,$sql);
        while($row=$result->fetch_assoc())
        {
            if($uid == $row['id'] or $uid == $row['building_name'])
        {

         ?>
         <tr>
         
         <td><?= $row["id"]?></td>
         <td><?= $row["building_name"]?></td>
         <td><?= $row["floors"]?></td>
         <td><?= $row["owner"]?></td>
         <td><?= $row["location"]?></td>
        </tr>
         <?php    
        }

}
   ?>
        </table>
</body>
</html>



