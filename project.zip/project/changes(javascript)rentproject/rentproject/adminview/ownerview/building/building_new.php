<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$query = "select * FROM building_owners";
$query_run = mysqli_query($conn, $query);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">
    <title>New Building</title>
</head>
<body>
  
    <div class="container mt-5">

    <a href="building.php" class="btn btn-danger float-end">BACK</a>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">

                        <?php
                        
                                ?>
                                <form action="insert_building.php" method="POST" >
                                <label>Id</label>
                                    <input type="text" name="id" class="form-control">

                                    <div class="mb-3">
                                        <label>Building Name</label>
                                        <input type="text" name="building_name"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Floor</label>
                                        <input type="text" name="floors"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Owner ID</label>
                                        <select name="owner" >
                                   <?php  while($row=mysqli_fetch_assoc($query_run))
                                     { ?>
        <option ><?php echo $row['id'] ?></option>
        <?php
                                     }  
                                     
                                     ?>
                                    </select>
                                    </div>
                                    <div class="mb-3">
                                        <label>Location</label>
                                        <input type="text" name="location"  class="form-control">
                                    </div>
                                   
                                    <div class="mb-3">
                                        <button type="submit" name="save_new" class="btn btn-primary">
                                            Save Building
                                        </button>
                                    </div>

                                </form>
                              
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>
</html>