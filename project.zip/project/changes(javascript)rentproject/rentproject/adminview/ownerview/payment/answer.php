<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from payment";
$result = mysqli_query($conn,$sql);


if(isset($_POST['delete_unit']))
{
    $id = mysqli_real_escape_string($conn, $_POST['delete_unit']);
    $num=$id;
    $query = "DELETE FROM payment WHERE sno='$id' ";

    $query_run = mysqli_query($conn, $query);
  
    while($row=$result->fetch_assoc())
    {
        $q="UPDATE `payment` SET `sno` = '$num' WHERE `payment`.`sno` = $num+1";
        $k= mysqli_query($conn,$q);
        $num++;
    }

    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: bos.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: bos.php");
        exit(0);
    }
}

if(isset($_POST['update_deposit']))
{
    $id=mysqli_real_escape_string($conn, $_POST['sno']);
    $sno = mysqli_num_rows($result);
    $sno++;
    $tenant = mysqli_real_escape_string($conn, $_POST['name']);
    $sql1="SELECT rent_of from invoice where tenant='$tenant'";
    $result1 = mysqli_query($conn,$sql1);
   while($row=mysqli_fetch_assoc($result1))
    {
        $rent_of = $row['rent_of'];
        
    }
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);
    $mode = mysqli_real_escape_string($conn, $_POST['mode']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);
    $date=mysqli_real_escape_string($conn, $_POST['date']);
   
  
    $query = "UPDATE payment SET date='$date',rent_of='$rent_of',tenant='$tenant',amount='$amount',mode='$mode',comment='$comment' WHERE sno='$id'";
    $query_run = mysqli_query($conn, $query);

  if($query_run)
    {
        $_SESSION['message'] = "Owners Updated Successfully";
        header("Location: payment.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Owners Not Updated";
        header("Location: payment.php");
        exit(0);
    }

}

/*
if(isset($_POST['save_student']))
{
    
    $sno = mysqli_num_rows($result);
    $sno++;
    $name_no = mysqli_real_escape_string($conn, $_POST['name_no']);
    $type = mysqli_real_escape_string($conn, $_POST['type']);
    $building = mysqli_real_escape_string($conn, $_POST['building']);
    $floor = mysqli_real_escape_string($conn, $_POST['floor']);
    $rent = mysqli_real_escape_string($conn, $_POST['rent']);
    $electricity_charges = mysqli_real_escape_string($conn, $_POST['electricity_charges']);
    $water_charges = mysqli_real_escape_string($conn, $_POST['water_charges']);
    $garbage_charges = mysqli_real_escape_string($conn, $_POST['garbage_charges']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

   $query = "INSERT INTO house_units (sno,name_no,type,building,floor,rent,electricity_charges,water_charges,garbage_charges,description,status) VALUES ('$sno',$name_no','$type',' $building',' $floor','$rent','$electricity_charges','$water_charges','$garbage_charges','$description','$status')";
  //$query = "  INSERT INTO `house_units` (`sno`, `name_no`, `type`, `building`, `floor`, `rent`, `electricity_charges`, `water_charges`, `garbage_charges`, `description`, `status`) VALUES ('$sno',$name_no','$type',' $building',' $floor','$rent','$electricity_charges','$water_charges','$garbage_charges','$description','$status')";
//INSERT INTO `house_units` (`sno`, `name_no`, `type`, `building`, `floor`, `rent`, `electricity_charges`, `water_charges`, `garbage_charges`, `description`, `status`) VALUES ('3', 'indira', 'multiStorey', 'Dhruv', '4', '10000', '200', '299', '0', 'nikal lode', 'Bhadva hai');
    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: house.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: house.php");
        exit(0);
    }
}*/
if(isset($_POST['save_new']))
{
   
  $sno = mysqli_num_rows($result);
    $sno++;
    $tenant = mysqli_real_escape_string($conn, $_POST['name']);
    $sql1="SELECT rent_of from invoice where tenant='$tenant'";
    $result1 = mysqli_query($conn,$sql1);
   while($row=mysqli_fetch_assoc($result1))
    {
        $rent_of = $row['rent_of'];
        
    }
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);
    $mode = mysqli_real_escape_string($conn, $_POST['mode']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);
    $date=mysqli_real_escape_string($conn, $_POST['date']);
   
   

   // $id = mysqli_real_escape_string($conn, $_POST['id']);
  //  $name = mysqli_real_escape_string($conn, $_POST['building_name']);
   // $floors = mysqli_real_escape_string($conn, $_POST['floor']);
 //   $rent = mysqli_real_escape_string($conn, $_POST['rent']);
   // $electricity_charges = mysqli_real_escape_string($conn, $_POST['electricity_charges']);
  /*  $owner = mysqli_real_escape_string($conn, $_POST['owner']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);*/
    $query = "INSERT INTO payment (sno,date,rent_of,tenant,amount,mode,comment) VALUES ('$sno','$date','$rent_of','$tenant','$amount','$mode','$comment')";

    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: payment.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: payment.php");
        exit(0);
    }
}


?>
