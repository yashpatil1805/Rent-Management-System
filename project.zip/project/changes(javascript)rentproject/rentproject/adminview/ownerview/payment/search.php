
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../mystyle.css">
</head>
<body>
   
    <table  border="2">
        
        <?php
    
          $uid=$_POST['search'];
            $conn=mysqli_connect("localhost","root","","rentdb");
            $sql="SELECT * from payment";
            $result = mysqli_query($conn,$sql);
            $cnt=0;
            $success=0;
            $n=mysqli_num_rows($result) ;
            $a=false;
                
            while($row=mysqli_fetch_assoc($result)){ 
                if((stripos("$row[tenant]","$uid")!==$a))
                {
                    if($success==0)
                    {
                        echo "<tr><tr>
                        <td>Sno</td> 
                        <td>Date</td> 
                        <td>Rent_of</td>
                        <td>Tenant</td>
                        <td>Amount</td>
                        <td>Mode</td>
                        <td>Comment</td></tr>";
                        $success++;
                    }
                    echo "<tr><td>". $row["sno"]."</td>
                    <td>".$row["date"]."</td>
                    <td>".$row["rent_of"]."</td>
                    <td> ".$row["tenant"]."</td>
                    <td> ".$row["amount"]."</td>
                    <td> ".$row["mode"]."</td>
                    <td> ".$row["comment"]."</td></tr>";
                } 
                else
                {
                    $cnt++;
               }
        } 

        if($cnt==$n)
        {
            echo"<center><h1>Search was Unsuccessful</h1></center>";
        }
        
        

/* LOGIC 0:
$result = mysqli_query($conn,$sql);
            $result1 = mysqli_query($conn,$sql);
            $cnt=0;
            $cnt1=0;
            $a=false;
            while($row=mysqli_fetch_assoc($result))
            {
               $n=mysqli_num_rows($result) ;
                if((stripos("$row[name]","$uid")===$a))
                {
                   
                    $cnt++;
                }
                else
                {
                    echo "<tr> <td>#</td> <td>Name</td><td>Phone</td> <td>Email</td> <td>Agent(%)</td><td>Date Joined</td> </tr>";
                    echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
                    
                }

            } 
            if($cnt==$n)
            {

                while($row1=mysqli_fetch_assoc($result1)){
                   
                if((stripos("$row1[id]","$uid")===$a) )
                {
                    $cnt1++;
                } 
                else
                {
                    echo "<tr><td>#</td> <td>Name</td><td>Phone</td><td>Email</td><td>Agent(%)</td><td>Date Joined</td></tr>";
                    echo"<tr><td>". $row1["id"]."</td><td>". $row1["name"]."</td><td>". $row1["phone"]."</td><td>". $row1["email"]."</td><td>". $row1["agent_percent"]."</td><td>". $row1["date_joined"]."</td></tr>";
                    
                }
            }
        }
        if($cnt==$cnt1)
        {
            echo"<center><h1>Search was Unsuccessful</h1></center>";
        }*/
/*  LOGIC 1:
$key=$_POST["search"];
    
    $conn=mysqli_connect("localhost","root","","rentdb");
    $sql="SELECT * from building_owners";
    $result=mysqli_query($conn,$sql);


        while($row=mysqli_fetch_assoc($result))
        {
            if($key == ($row['id'] or $row['name']))
           {
                echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
            }
            else{
                echo "person not found";
            }
        }*/
    /*    $uid=$_POST['search'];
        $conn=mysqli_connect("localhost","root","","rentdb");
        $sql="SELECT * from building_owners";
        $result = mysqli_query($conn,$sql);
        while($row=mysqli_fetch_assoc($result))
        {
            if($uid == $row['id'])
            {
                echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
            }
        } */
        
    //   while($row=$result->fetch_assoc()){
      //      echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
          
      //}*/


              /* LOGIC 2:
                 if(is_numeric($uid))
            {
                while($row=mysqli_fetch_assoc($result)){ 
                    if((stripos("$row[id]","$uid")===$a) )
                    {
                        $cnt++;
                    } 
                    else
                    {
                        echo "<tr><td>#</td> <td>Name</td><td>Phone</td><td>Email</td><td>Agent(%)</td><td>Date Joined</td></tr>";
                        echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";      
                    }
            }    
        }
        else
        {  
            while($row=mysqli_fetch_assoc($result))
            {  
                if((stripos("$row[name]","$uid")===$a))
                {      
                    $cnt++;
                }
                else
                {
                    echo "<tr> <td>#</td> <td>Name</td><td>Phone</td> <td>Email</td> <td>Agent(%)</td><td>Date Joined</td> </tr>";
                    echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";       
                }
            }
    }   */
      ?>
       
    </table>
      </body>
      </html>