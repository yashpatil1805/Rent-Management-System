<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from unittype";
$result = mysqli_query($conn,$sql);

if(isset($_POST['new_type']))// new_type kha se aa rha h
{
    
    $id = mysqli_real_escape_string($conn, $_POST['new_type']);
    $sno = mysqli_num_rows($result);
    $sno++;
    $building=$_POST['building'];
    $owner_id=strtok($building,",");
    $owner_id=strtok(",");
    $owner_id=strtok(",");
    $owner_id=strtok(",");
    $buildingid=$_POST['building'];
    $buildingid=strtok($buildingid,",");
    $buildingid=strtok(",");

    $query = "INSERT INTO unittype (sno,type,buildingname,ownerid,buildingid) VALUES ('$sno','$id','$building','$owner_id','$buildingid')";
    $query_run = mysqli_query($conn, $query);
    

    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: main.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: main.php");
        exit(0);
    }
}

if(isset($_POST['update_type']))
{
    $id = mysqli_real_escape_string($conn, $_POST['sno']);
    $name = mysqli_real_escape_string($conn, $_POST['type']);

   

    $query = "UPDATE unittype SET type='$name' WHERE sno='$id' ";
    $query_run = mysqli_query($conn, $query);


  if($query_run)
    {
        $_SESSION['message'] = "Owners Updated Successfully";
        header("Location: main.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Owners Not Updated";
        header("Location: main.php");
        exit(0);
    }

}

/*

if(isset($_POST['save_new']))
{

    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['building_name']);
    $floors = mysqli_real_escape_string($conn, $_POST['floors']);
    $owner = mysqli_real_escape_string($conn, $_POST['owner']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $query = "INSERT INTO building (id,building_name,floors,owner,location) VALUES ('$id','$name','$floors','$owner','$location')";

    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: building.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: building.php");
        exit(0);
    }
}*/
if(isset($_POST['delete_type']))
{
    $id = mysqli_real_escape_string($conn, $_POST['delete_type']);
    $num=$id;
    $query = "DELETE FROM unittype WHERE sno='$id'";
    $query_run = mysqli_query($conn, $query);

    while($row=$result->fetch_assoc())
    {
        $q="UPDATE `unittype` SET `sno` = '$num' WHERE `unittype`.`sno` = $num+1";
        $k= mysqli_query($conn,$q);
        $num++;
    }


    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: main.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: main.php");
        exit(0);
    }
}

?>