
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<style>
    div{
        background-color: antiquewhite;
        padding: 0px;
    }
    .view{
        margin-top: 150px;
        padding: 0px;
    }
    table{
        width: 1200px;
        height: 150px;

    }
    a{
        text-decoration: none;
    }
    td{
        text-align: center;

    }
    ul{
        display: flex;

    }
    li{
        list-style: none;

    }
    .btn{
        margin-left: 0px;
    margin-top: 15px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .new{
        margin-left: 800px;
    margin-top: 20px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .search{
        margin-left: 840px;
    margin-top: 15px;
    }
    table.center
    {
        margin-left: auto;
        margin-right: auto;
    }
    
</style>
<body>
    <div class="mydash">
       <ul>
        <li>
        <p>
          List of Building Owners  
        </p>
        </li>
        <li>
        <a href="building_owners_new.php?"class="new">New+</a>
        </li>
       </ul> 

    </div>
    <div class="entries">
       <ul>
        <li>
        <label for="cars">Show</label>

<select name="entry" id="cars">
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option selected value="4">4</option>
  entries
</select>

        </li>
        <li class="search">
        <form action="bos.php" method="POST">
         Search: <input type="text" name="search">
        
       
      
        </form>
        </li>
       </ul> 

    </div>
   
    <table class="center" border="2">
        <tr>
            <td>#</td> 
            <td>Name</td>
            <td>Phone</td>
            <td>Email</td>
            <td>Agent(%)</td>
            <td>Date Joined</td>
            <td colspan="3">Action</td>
        </tr>
        <?php
      /*  $key=$_POST["search"];
    
        $conn=mysqli_connect("localhost","root","","rentdb");
        $sql="SELECT * from building_owners";
        $result=mysqli_query($conn,$sql);

    
            while($row=mysqli_fetch_assoc($result))
            {
                if($key == ($row['id'] or $row['name']))
               {
                    echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
                }
                else{
                    echo "person not found";
                }
            }*/
        /*    $uid=$_POST['search'];
            $conn=mysqli_connect("localhost","root","","rentdb");
            $sql="SELECT * from building_owners";
            $result = mysqli_query($conn,$sql);
            while($row=mysqli_fetch_assoc($result))
            {
                if($uid == $row['id'])
                {
                    echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
                }
            } */
            
        //   while($row=$result->fetch_assoc()){
          //      echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
              
          //}
       //   $uid=$_POST['search'];
            $conn=mysqli_connect("localhost","root","","rentdb");
            $sql="SELECT * from building_owners";
            $result = mysqli_query($conn,$sql);
            while($row=$result->fetch_assoc())
            {
                ?>
                <tr>
                
                <td><?= $row["id"]?></td>
                <td><?= $row["name"]?></td>
                <td><?= $row["phone"]?></td>
                <td><?= $row["email"]?></td>
                <td><?= $row["agent_percent"]?></td>
                <td><?= $row["date_joined"]?></td>
                <td>  <a href="building_owners_view.php?id=<?= $row['id'];?>"class="btn">View</a></td>
                <td>  <a href="building_owners_edit.php?id=<?= $row['id'];?>"class="btn">Edit</a></td>
                <td>   <form action="insert.php" method="POST" class="d-inline">
                                                        <button type="submit" name="delete_student" value="<?=$row['id'];?>" class="btn btn-danger btn-sm">Delete</button>
                                                    </form></td></tr>
                <?php    
          }
         /*   while($row=mysqli_fetch_assoc($result))
            {
                if($uid == $row['id'])
                {
                    echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
                }
            }   */
        
        ?>
       
    </table>
</body>
</html>



