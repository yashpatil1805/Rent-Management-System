<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from house_units";
$result = mysqli_query($conn,$sql);
$count = mysqli_num_rows($result);
$sql1="SELECT * from vacated_tenants";
$result1 = mysqli_query($conn,$sql1);
$count1 = mysqli_num_rows($result1);
$sql2="SELECT * from active_tenants";
$result2 = mysqli_query($conn,$sql2);
$count2 = mysqli_num_rows($result2);
$sql3="SELECT * from building";
$result3 = mysqli_query($conn,$sql3);
$count3 = mysqli_num_rows($result3);
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide|Sofia|Trirong&effect=fire|neon|outline|emboss|shadow-multiple">
</head>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide|Sofia|Trirong">

       
<style>

    .dash{
        border-radius: 20px;
        background-color:wheat;
    }
    div{
        
        padding: 10px;
        border-radius: 10px;
    }
    .container{

    display: grid;
    grid-template-columns: 2fr 2fr 2fr 2fr;
    border-radius: 10px;
    
    }
    body{
        background-color:wheat;
        border-radius: 10px;
        font-size: 14px;
            font-family: "trirong", sans-serif;
       

    }
    .grid{
    height: 200px;
    width: 230px;
    padding: 2px;
    border: 5px solid rgb(214 228 172);
    margin: 20px;
    border-radius: 20px;
    }
    #box-1
    {
        background-image: linear-gradient(rgb(137 185 122),rgb(255, 255, 255));
    }
    #box-2
    {
        background-image: linear-gradient(rgb(204 206 106),rgb(255, 255, 255));
    }
    #box-3
    {
        background-image: linear-gradient(rgb(224 179 117),rgb(255, 255, 255));
    }
    #box-4
    {
        background-image: linear-gradient(rgb(149 197 203),rgb(255, 255, 255));
    }
    .view{
        margin-top: 150px;
        padding: 0px;
    }
    table{
        width: 1200px;
        height: 150px;
        background-color:tan;   
        border:none; 
    }

td{
    border-radius: 10px;
}


    
</style>
<body>
    <div class="dash">
    <div class="mydash">
        <p>
        <h2 class="font-effect-outline">My Dashboard</h2>
        </p>
    </div>
    <div class="container">
        <div class="grid" id="box-1"><br><br><h1><?php echo $count ?> House Units
           
</h1> </div>
        <div class="grid" id="box-2"><br><br><h1><?php echo $count1 ?> Vacant Units  </h1></div>
        <div class="grid" id="box-3"><br><br><h1><?php echo $count2 ?> Active Tenants </h1></div>
        <div class="grid" id="box-4"><br><br><h1><?php echo $count3 ?> Buildings  </h1></div>
    </div>

    <table  border="2">
        <tr>
            <td>#</td> 
            <td>Name</td>
            <td>Phone</td>
            <td>House Rented</td>
            <td>Date Occupied</td>
        </tr>
        <?php
        $conn=mysqli_connect("localhost","root","","rentdb");
        $sql="SELECT * from tenants";
        $result=mysqli_query($conn,$sql);

        if($result->num_rows>0)
        {
            while($row=$result->fetch_assoc()){
                echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["hrepair"]."</td><td>". $row["dateoccupied"]."</td></tr>";
              
            }
        }
        ?>
       
    </table>
    </div>
</body>
</html>



