<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * FROM building";
$result = mysqli_query($conn,$sql);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Building Edit</title>
</head>
<body>
  
    <div class="container mt-5">

       #

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Building Edit 
                            <a href="building.php" class="btn btn-danger float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <?php
                        if(isset($_GET['id']))
                        {
                            $b_id = mysqli_real_escape_string($conn, $_GET['id']);
                            $query = "SELECT * FROM building WHERE id='$b_id' ";
                            $query_run = mysqli_query($conn, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $build = mysqli_fetch_array($query_run);
                                ?>
                                <form action="insert_building.php" method="POST">
                                    <input type="hidden" name="id" value="<?= $build['id']; ?>">

                                    <div class="mb-3">
                                        <label>Name</label>
                                        <input type="text" name="building_name" value="<?=$build['building_name'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Floors</label>
                                        <input type="text" name="floors" value="<?=$build['floors'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Owner</label>
                                        <input type="text" name="owner" value="<?=$build['owner'];?>"  class="form-control" >
                                    </div>
                                    <div class="mb-3">
                                        <label>Location</label>
                                        <input type="text" name="location" value="<?=$build['location'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <button type="submit" name="delete_student" class="btn btn-primary">
                                            Update Student
                                        </button>
                                    </div>

                                </form>
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>