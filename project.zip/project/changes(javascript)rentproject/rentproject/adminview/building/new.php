
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<style>
    div{
        background-color: antiquewhite;
        padding: 0px;
    }
    .view{
        margin-top: 150px;
        padding: 0px;
    }
    table{
        width: 1200px;
        height: 150px;

    }
    a{
        text-decoration: none;
    }
    td{
        text-align: center;

    }
    ul{
        display: flex;

    }
    li{
        list-style: none;

    }
    .btn{
        margin-left: 0px;
    margin-top: 15px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .new{
        margin-left: 800px;
    margin-top: 20px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .search{
        margin-left: 840px;
    margin-top: 15px;
    }
    table.center
    {
        margin-left: auto;
        margin-right: auto;
    }
    
</style>
<body>
    <div class="mydash">
       <ul>
        <li>
        <p>
          List of Buildings...
        </p>
        </li>
        <li>
        <a href="building_new.php?"class="new">New</a>
        </li>
       </ul> 

    </div>
    <div class="entries">
       <ul>
        <li>
        <label for="cars">Show</label>

<select name="entry" id="cars">
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option selected value="4">4</option>
  entries
</select>

        </li>
        <li class="search">
        <form action="build.php" method="POST">
         Search: <input type="text" name="search">
        
       
      
        </form>
        </li>
       </ul> 

    </div>
   
    <table class="center" border="2">
        <tr>
            <td>#</td> 
            <td>Building Name</td>
            <td>Floors</td>
            <td>Owner</td>
            <td>Location</td>
            <td colspan="2">Action</td>
            </tr>
            <?php  
        $conn=mysqli_connect("localhost","root","","rentdb");
        $sql="SELECT * FROM building";
        $result = mysqli_query($conn,$sql);
        while($row=$result->fetch_assoc())
        {
         ?>
         <tr>
         
         <td><?= $row["id"]?></td>
         <td><?= $row["building_name"]?></td>
         <td><?= $row["floors"]?></td>
         <td><?= $row["owner"]?></td>
         <td><?= $row["location"]?></td>
         <td>  <a href="building_edit.php?id=<?= $row['id'];?>"class="btn">Edit</a></td>
         <td>   <form action="insert_building.php" method="POST" class="d-inline">
                                                 <button type="submit" name="delete_student" value="<?=$row['id'];?>" class="btn btn-danger btn-sm">Delete</button>
                                             </form></td></tr>
         <?php    
   }
   ?>
        </table>
</body>
</html>



