<?php
$conn=mysqli_connect("localhost","root","","rentdb");


if(isset($_POST['delete_student']))
{
    $id = mysqli_real_escape_string($conn, $_POST['delete_student']);

    $query = "DELETE FROM building WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    $query1 = "SELECT * FROM unittype";
    $query_run1 = mysqli_query($conn, $query1);
   
    while($row1=$query_run1->fetch_assoc())
    {
        if($row1["buildingid"]==$id)
        {
            $query2 = "DELETE FROM unittype WHERE buildingid='$id' ";
            $query_run2 = mysqli_query($conn, $query2);
        }
    }    
    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: building.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: building.php");
        exit(0);
    }
}

if(isset($_POST['update_building']))
{
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['building_name']);
    $floors = mysqli_real_escape_string($conn, $_POST['floors']);
    $owner = mysqli_real_escape_string($conn, $_POST['owner']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);

   

    $query = "UPDATE building SET building_name='$name',floors='$floors', owner='$owner',location='$location' WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

  if($query_run)
    {
        $_SESSION['message'] = "Owners Updated Successfully";
        header("Location: building.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Owners Not Updated";
        header("Location: building.php");
        exit(0);
    }

}


if(isset($_POST['save_new']))
{

    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['building_name']);
    $floors = mysqli_real_escape_string($conn, $_POST['floors']);
    $owner = mysqli_real_escape_string($conn, $_POST['owner']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    
    // $ans = "select name from building_owner where id = '$owner'";
    $ans="select * from building_owners";
    $que = mysqli_query($conn, $ans);
    while($row=$que->fetch_assoc())
        {
        if($row["id"]==$owner)
        {
            $ownername=$row["name"];
        }
    }
    $query = "INSERT INTO building (id,building_name,floors,owner,location,owner_id) VALUES ('$id','$name','$floors','$ownername','$location','$owner')";

    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: building.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: building.php");
        exit(0);
    }
}

?>