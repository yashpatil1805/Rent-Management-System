
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide|Sofia|Trirong&effect=fire|neon|outline|emboss|shadow-multiple">
</head>
<style>
    div{
        background-color: antiquewhite;
        padding: 0px;
    }
    .view{
        margin-top: 150px;
        padding: 0px;
    }
    table{
        width: 1200px;
        height: 150px;

    }
    a{
        text-decoration: none;
    }
    td{
        text-align: center;

    }
    ul{
        display: flex;

    }
    li{
        list-style: none;

    }
    .btn{
        margin-left: 0px;
    margin-top: 15px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    body{
        background-color:antiquewhite
    }
    .new{
        margin-left: 800px;
    margin-top: 20px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .search{
        margin-left: 840px;
    margin-top: 15px;
    }
    table.center
    {
        margin-left: auto;
        margin-right: auto;
    }
    
</style>
<body>
    <div class="mydash">
       <ul>
        <li>
        <p>
        <h2 class="font-effect-shadow-multiple">List Of Building.....</h2>
        </p>
        </li>
        <li>
        <a href="building_new.php"class="new" target="dashboard">New</a>
        </li>
       </ul> 

    </div>
    <div class="entries">
       <ul>
        <li>
    

        </li>
        <li class="search">
        <form action="search.php" method="POST" target="bos">
         Search: <input type="text" name="search">
        <a href="bos.php" target="bos">BACK</a>
       
      
        </form>
        </li>
       </ul> 

    </div>
   
    
        
</body>
</html>



