<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title></title>
</head>
   
    

    <frameset rows="30%,*" frameborder="NO" framespacing="0"  scrolling="NO">
		<frame src="buildingnavbar.php" name="buildingnavbar"  noresize="noresize" border="0" scrolling="NO">
		</frame>
   
    
        <frame src="bos.php" name="bos" noresize="noresize" border="0"
		</frame>

	</frameset>
</html>