
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>


    <?php
    session_start();
if(isset($_POST['submit']))
{
    $conn=mysqli_connect("localhost","root","","rentdb");
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);
    if($password!=$confirm_password)
    {
        $_SESSION['passwordnotmatch'] = "The Password you Entered Doesn't Match";
        header("Location: ownersignup.php");
        exit(0);
    }
    else
    {
    ?>
    <form action="oe2.php" method="POST" >
                             
    <div class="mb-3">
        <label>Name</label>
        <input type="text" name="name"  class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Agent</label>
        <input type="text" name="agent_percent"  class="form-control"  required>
    </div>
    <div class="mb-3">
        <label>Date Joined</label>
        <input type="date" name="date joined"  class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Agreement Date</label>
        <input type="date" name="agreement_date"  class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Status</label>
        <input type="text" name="status"  class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Passport Photo</label>
        <input type="file" name="passport_photo"  class="form-control" required>
    </div>
    <div class="mb-3">
        <label>agreement</label>
        <input type="file" name="agreement"  class="form-control" required>
    </div>
    <div class="mb-3">
       <button type="submit" name="save_student" class="btn btn-primary" required> 
            Save Owner
        </button>
    </div>

</form>
<?php
    $id=rand(10,10000);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
     $email = mysqli_real_escape_string($conn, $_POST['email']);
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
    $query = "INSERT INTO ownerlogin (id,username,password,name,email,mobile_no) VALUES ('$id','$username','$password','$name','$email','$mobile')";
    $query_run = mysqli_query($conn, $query);
    }
}


?>
</body>
</html>



