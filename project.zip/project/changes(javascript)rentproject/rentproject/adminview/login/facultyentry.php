
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<?php
session_start();
            $conn=mysqli_connect("localhost","root","","projecthub");
            $sql="SELECT * from signup";
            $result = mysqli_query($conn,$sql);
           
if(isset($_POST['submit']))
{
    
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirmpassword = mysqli_real_escape_string($conn, $_POST['confirmpassword']);
    if($password!=$confirmpassword)
    {
        $_SESSION['passwordnotmatch'] = "The Password you Entered Doesn't Match";
        header("Location: facultysignup.php");
        exit(0);
    }
    $aishecode = mysqli_real_escape_string($conn, $_POST['aishecode']);
    $collegename = mysqli_real_escape_string($conn, $_POST['collegename']);
    $facultyname = mysqli_real_escape_string($conn, $_POST['facultyname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
    $query = "INSERT INTO signup (username,password,confirmpassword,aishecode,collegename,facultyname,email,mobile) VALUES ('$username','$password','$confirmpassword','$aishecode','$collegename','$facultyname','$email','$mobile')";
    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Faculty Created Successfully";
        header("Location: facultysignup.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Faculty Not Created";
        header("Location: facultysignup.php");
        exit(0);
    }
}



?>
</body>
</html>



