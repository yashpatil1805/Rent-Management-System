<?php
$a="yash";
$x=setcookie("myname","$a",time()+86400,"/");
if($x)
{
    echo("The Cookie has been set");
}
else
{
    echo("Nhi hua bhai");
}
?>