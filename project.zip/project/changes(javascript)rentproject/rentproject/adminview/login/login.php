<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Hub</title>
    <style>
        body{
            background-color: antiquewhite;
            height:500px;
        }
    </style>
</head>
<body>
<?php
session_start();
    if(isset($_SESSION['message']))
    {
        echo "<h3>".($_SESSION['message'])."<h3>";
        unset($_SESSION['message']);
    }
    ?>
    <div class="loginbox">
        <form action="check.php" method="POST">
             LOGIN <br>

            USERNAME: <input type="text" name="username" placeholder="Enter your Username" minlength="6" >
            <br>
            PASSWORD: <input type="password" name="password" placeholder="Enter your Password" minlength="6" > <br>
            <input type="submit" name="submit" value="Submit">
        </form>
    </div>
</body>
</html>