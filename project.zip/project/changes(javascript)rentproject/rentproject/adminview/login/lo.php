<!DOCTYPE html>
<html>
<head>
  <title>Login Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
    }
    .login-box {
      width: 300px;
      margin: 100px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease-in-out;
    }
    .login-box:hover {
      transform: scale(1.05);
    }
    .welcome-message {
      text-align: center;
      font-size: 24px;
      margin-bottom: 20px;
      opacity: 0;
      transition: opacity 0.5s ease-in-out;
    }
    .show {
      opacity: 1;
    }
  </style>
</head>
<body>
  <?php
    // Check if the form is submitted
    if(isset($_POST['username'])) {
      $username = $_POST['username'];
      $password = $_POST['password'];

      // Here, you would typically check against a database or some source for valid credentials
      // For the sake of simplicity, a basic check is used here
      if($username === 'user' && $password === 'password') {
        echo '<div class="login-box">';
        echo '<div class="welcome-message">Welcome, ' . htmlspecialchars($username) . '!</div>';
        echo '</div>';
        echo '<script>document.querySelector(".welcome-message").classList.add("show");</script>';
      } else {
        echo '<div class="login-box">';
        echo '<div class="welcome-message">Invalid credentials. Please try again.</div>';
        echo '</div>';
        echo '<script>document.querySelector(".welcome-message").classList.add("show");</script>';
      }
    } else {
  ?>
  <div class="login-box">
    <h2>Login</h2>
    <form method="post">
      <input type="text" name="username" placeholder="Username" required><br><br>
      <input type="password" name="password" placeholder="Password" required><br><br>
      <button type="submit">Login</button>
    </form>
  </div>
  <?php } ?>
</body>
</html>
