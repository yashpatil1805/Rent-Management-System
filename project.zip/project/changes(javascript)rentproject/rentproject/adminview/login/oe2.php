<?php
 $conn=mysqli_connect("localhost","root","","rentdb");

$name=$_POST['name'];
            $query1 = "SELECT * FROM ownerlogin" ; 
            $query_run1 = mysqli_query($conn, $query1);
            while($row=$query_run1->fetch_assoc())
            {
                if($name==$row['username'])
                {
                    $id=$row['id'];
                    $username=$row['username'];
                    $email=$row['email'];
                    $mobile=$row['mobile_no'];
                }
            }
            
            $name = mysqli_real_escape_string($conn, $_POST['name']);
            $agent_percent = mysqli_real_escape_string($conn, $_POST['agent_percent']);
            $date_joined = mysqli_real_escape_string($conn, $_POST['date_joined']);
            $agreement_date = mysqli_real_escape_string($conn, $_POST['agreement_date']);
            $status = mysqli_real_escape_string($conn, $_POST['status']);
            $passport_photo = mysqli_real_escape_string($conn, $_POST['passport_photo']);
            $agreement = mysqli_real_escape_string($conn, $_POST['agreement']);
        
            $query = "INSERT INTO building_owners (id,name,phone,email,agent_percent,date_joined,agreement_date,status,passport_photo,agreement) VALUES ('$id','$username','$mobile','$email','$agent_percent','$date_joined','$agreement_date','$status','$passport_photo','$agreement')";
            $query_run = mysqli_query($conn, $query);
           
    if($query_run)
    {
        $_SESSION['signup'] = "Registration Successful";
        header("Location: LOGINmain.php");
        exit(0);
    }
           ?>