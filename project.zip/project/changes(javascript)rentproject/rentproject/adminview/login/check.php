
<?php
session_start();
            $conn=mysqli_connect("localhost","root","","rentdb");
            $sql="SELECT * from ownerlogin";
            $result = mysqli_query($conn,$sql);
            $correctcount=false; 
            
if(isset($_POST['submit']))
{
    $choice=    mysqli_real_escape_string($conn, $_POST['f']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    // if($choice=="owner")
    // {
        while($row=$result->fetch_assoc())
        {
    
            if($row['username']!=$username)
            {
                $_SESSION['message'] = "Username is Invalid ";
                header("Location: loginMain.php");
                exit(0);
                   
            }
            if($row['password']==$password)
            {
                $oidc=$row['id'];
                $correctcount=true;
                setcookie("oid","$oidc",time() + 86400,"/");
                header("Location: ../ownerview/home.html");
                die();

            }   
         }

         if($correctcount!=true){
            $_SESSION['notfound'] = "Invalid Entry";
            $_SESSION['wrongps']=$_SESSION['wrongps']+1;
            if($_SESSION['wrongps']==3)
            {
                $_SESSION['currenttime']=time();
                $_SESSION['ctflag']=true;
            }
            header("Location: loginmain.php");
            exit(0);
        }

    }

    // }




?>




