<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from building";
$result = mysqli_query($conn,$sql);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>New House Unit</title>
    <style>
        body{
            background-color: antiquewhite;
        }
        .card-body {
    flex: 1 1 auto;
    padding: 1rem 1rem;
    background-color: antiquewhite;
}
       
    </style>
</head>
<body>
  
    <div class="container mt-5">

    <a href="house.php" class="btn btn-danger float-end">BACK</a>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">

                        <?php
                        
                                ?>
                                <form action="answer.php" method="POST">
                                <div class="mb-3">
                                        <label>Name</label>
                                        <input type="text" name="name_no"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>type</label>
                                        <input type="text" name="type"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>building</label>
                                        <?php  
        
            while($row=mysqli_fetch_assoc($result))
                                     {
                                              ?>
        <option ><?php echo $row['building_name'].",".$row['id'].",".$row['owner_id']?></option>
        
        <?php
                   
                                   }  
                                     
                                     ?>
            </select>
                                    </div>
                                    <div class="mb-3">
                                        <label>floor</label>
                                        <input type="text" name="floor"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>rent</label>
                                        <input type="text" name="rent"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>electricity_charges</label>
                                        <input type="text" name="electricity_charges"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>water_charges</label>
                                        <input type="text" name="water_charges"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>garbage_charges</label>
                                        <input type="text" name="garbage_charges"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>description</label>
                                        <input type="text" name="description"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>status</label>
                                        <input type="text" name="status"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <button type="submit" name="save_unit" class="btn btn-primary">
                                            Save Unit
                                        </button>
                                        
                                    </div>

                                </form>
                                <?php
                            
                           
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>
</html>