
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<style>
    body{
        background-color:antiquewhite
    }
    div{
        background-color: antiquewhite;
        padding: 0px;
    }
    .view{
        margin-top: 150px;
        padding: 0px;
    }
    table{
        width: 1200px;
        height: 150px;

    }
    a{
        text-decoration: none;
    }
    td{
        text-align: center;

    }
    ul{
        display: flex;

    }
    li{
        list-style: none;

    }
    .btn{
        margin-left: 0px;
    margin-top: 15px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .new{
        margin-left: 800px;
    margin-top: 20px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .search{
        margin-left: 840px;
    margin-top: 15px;
    }
    table.center
    {
        margin-left: auto;
        margin-right: auto;
    }
    
</style>
<body>
<label for="cars">Show</label>
<form action="bos.php" method="POST">
<select name="ent">
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option selected value="4">4</option>
  entries
</select>
<input type="submit" value="submit" >
</form>
   
   
    <table class="center" border="2">
        <tr>
            <td>#</td> 
            <td>Unit name</td>
            <td>Buidling</td>
            <td>Monthly Rent</td>
            <td>Status</td>
            <td colspan="3">Action</td>
        </tr>
        <?php
      /*  $key=$_POST["search"];
    
        $conn=mysqli_connect("localhost","root","","rentdb");
        $sql="SELECT * from building_owners";
        $result=mysqli_query($conn,$sql);

    
            while($row=mysqli_fetch_assoc($result))
            {
                if($key == ($row['id'] or $row['name']))
               {
                    echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
                }
                else{
                    echo "person not found";
                }
            }*/
        /*    $uid=$_POST['search'];
            $conn=mysqli_connect("localhost","root","","rentdb");
            $sql="SELECT * from building_owners";
            $result = mysqli_query($conn,$sql);
            while($row=mysqli_fetch_assoc($result))
            {
                if($uid == $row['id'])
                {
                    echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
                }
            } */
            
        //   while($row=$result->fetch_assoc()){
          //      echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
              
          //}
       //   $uid=$_POST['search'];
            $conn=mysqli_connect("localhost","root","","rentdb");
            $sql="SELECT * from house_units";
            $result = mysqli_query($conn,$sql);
            if($_SERVER['REQUEST_METHOD']=='GET'){
                while($row=$result->fetch_assoc())
                {
                    ?>
                    <tr>
                    
                    <td><?= $row["sno"]?></td>
                    <td><?= $row["name_no"]?></td>
                    <td><?= $row["building"]?></td>
                    <td><?= $row["rent"]?></td>
                    <td><?= $row["status"]?></td>
                    <td>  <a href="view.php?sno=<?= $row['sno'];?>"class="btn" target="dashboard">View</a></td>
                    <td>  <a href="edit2.php?sno=<?= $row['sno'];?>"class="btn" target="dashboard">Edit</a></td>
                    <td>   <form action="answer.php" method="POST" class="d-inline">
                                                            <button type="submit" name="delete_unit" value="<?=$row['sno'];?>" class="btn btn-danger btn-sm">Delete</button>
                                                        </form></td></tr>
                    <?php
    
              }
            }
            elseif($_SERVER['REQUEST_METHOD']=='POST')
         {
             $count=$_POST['ent'];
         $c=0;
             while($row=$result->fetch_assoc())
             {
                if($count>$c)
                {
                 $c++;
                 ?>
                  <tr>
                    
                    <td><?= $row["sno"]?></td>
                    <td><?= $row["name_no"]?></td>
                    <td><?= $row["building"]?></td>
                    <td><?= $row["rent"]?></td>
                    <td><?= $row["status"]?></td>
                    <td>  <a href="view.php?sno=<?= $row['sno'];?>"class="btn" target="dashboard">View</a></td>
                    <td>  <a href="edit2.php?sno=<?= $row['sno'];?>"class="btn" target="dashboard">Edit</a></td>
                    <td>   <form action="answer.php" method="POST" class="d-inline">
                                                            <button type="submit" name="delete_unit" value="<?=$row['sno'];?>" class="btn btn-danger btn-sm">Delete</button>
                                                        </form></td></tr>
                    <?php
    
              }
            }
        }
        
         /*   while($row=mysqli_fetch_assoc($result))
            {
                if($uid == $row['id'])
                {
                    echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
                }
            }   */
            
        ?>
       
    </table>
</body>
</html>



