<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from house_units";
$result = mysqli_query($conn,$sql);
$bu="SELECT building_name from building";
$result1 = mysqli_query($conn,$bu);
$unit="SELECT type from unittype";
$result2 = mysqli_query($conn,$unit);
$floors="SELECT floors from building";
$result3 = mysqli_query($conn,$floors);


/*if(mysqli_num_rows($result1) > 0)  
{
    $building[] = array();
    while($buil=$result1->fetch_assoc())         
    {
        $building[] = $buil;      
    }
}
else
{
    echo "NO products found";
}*/
//$b="SELECT * from house_units";
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Edit House Unit</title>
    <style>
           .card-body {
    flex: 1 1 auto;
    padding: 1rem 1rem;
    background-color: antiquewhite;
}
       body{
        background-color: antiquewhite;
       }
    </style>
</head>
<body>
  
    <div class="container mt-5">

       

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4> Edit House Units
                            <a href="house.php" class="btn btn-danger float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <?php
                      /*  $b=$_GET['sno'];
                        echo $b;*/
                     if(isset($_GET['sno']))
                     {
                         $b_id = mysqli_real_escape_string($conn, $_GET['sno']);
                         $query = "SELECT * FROM house_units WHERE sno='$b_id' ";
                         $query_run = mysqli_query($conn, $query);
                    /*    $a=mysqli_num_rows($query_run);
                        echo $a;*/
                         if(mysqli_num_rows($query_run) > 0)
                         {
                             $unit = mysqli_fetch_array($query_run);
                             ?>
                             <form action="answer.php" method="POST">
                                  <input type="hidden" name="sno" value="<?= $unit['sno']; ?>">
                             <div class="mb-3">
                                     <label>name_no</label>
                                     <input type="text" name="name_no" value="<?=$unit['name_no'];?>" class="form-control">
                                 </div>
                             <div class="mb-3">
                                     <label>type</label>
                                     <select name="type" >
                                   <?php  while($row1=mysqli_fetch_assoc($result2))
                                     { ?>
        <option ><?php echo $row1['type'] ?></option>
        <?php
                                     }  
                                     ?>
                                    </select> 
                             <div class="mb-3">
                                     <label>Building</label>
                                     <select name="building" >
                                   <?php  while($row=mysqli_fetch_assoc($result1))
                                     { ?>
        <option ><?php echo $row['building_name'] ?></option>
        <?php
                                     }  
                                     ?>
                                    </select>                               
                             </div>
                             <div class="mb-3">
                                     <label>floor</label>
                                     <select name="floor" >
                                   <?php  while($row=mysqli_fetch_assoc($result3))
                                     { ?>
        <option ><?php echo $row['floors'] ?></option>
        <?php
                                     }  
                                     ?>
                                    </select>    </div>
                             <div class="mb-3">
                                     <label>rent</label>
                                     <input type="text" name="rent" value="<?=$unit['rent'];?>" class="form-control">
                                 </div>
                             <div class="mb-3">
                                     <label>Electricity Charges</label>
                                     <input type="text" name="electricity_charges"  value="<?=$unit['electricity_charges'];?>"class="form-control">
                                 </div>
                             <div class="mb-3">
                                     <label>Water Charges</label>
                                     <input type="text" name="water_charges" value="<?=$unit['water_charges'];?>" class="form-control">
                                 </div>
                             <div class="mb-3">
                                     <label>Garbage Charges</label>
                                     <input type="text" name="garbage_charges" value="<?=$unit['garbage_charges'];?>" class="form-control">
                                 </div>
                             <div class="mb-3">
                                     <label>Description</label>
                                     <input type="text" name="description" value="<?=$unit['description'];?>" class="form-control">
                                 </div>
                             <div class="mb-3">
                                     <label>Status</label>
                                     <input type="text" name="status" value="<?=$unit['status'];?>" class="form-control">
                                 </div>
                                 
                          

                                    
                                 <div class="mb-3">
                                     <button type="submit" name="update" class="btn btn-primary">
                                         Save Unit
                                     </button>
                                     
                                 </div>

                             </form>
                               
                        <?php
                         }
                          ?> 
                             <?php
                         }
                         else
                         {
                             echo "<h4>No Such Id Found</h4>";
                         }
                     
                     ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>