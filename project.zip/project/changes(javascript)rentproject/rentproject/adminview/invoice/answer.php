<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from invoice";
$result = mysqli_query($conn,$sql);
if(isset($_POST['delete_unit']))
{
    $id = mysqli_real_escape_string($conn, $_POST['delete_unit']);
    $num=$id;
    $query = "DELETE FROM invoice WHERE sno='$id' ";

    $query_run = mysqli_query($conn, $query);
  
    while($row=$result->fetch_assoc())
    {
        $q="UPDATE `invoice` SET `sno` = '$num' WHERE `invoice`.`sno` = $num+1";
        $k= mysqli_query($conn,$q);
        $num++;
    }

    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: bos.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: bos.php");
        exit(0);
    }
}

if(isset($_POST['update_deposit']))
{
    $id = mysqli_real_escape_string($conn, $_POST['sno']);
    $sql1="SELECT rent,electricity_charges,water_charges,garbage_charges FROM house_units";
    $result1 = mysqli_query($conn,$sql1);
  $sno = mysqli_num_rows($result);
    $sno++;
    $tenant = mysqli_real_escape_string($conn, $_POST['name']);
    $rent_of = mysqli_real_escape_string($conn, $_POST['rent_of']);
    $other_charges = mysqli_real_escape_string($conn, $_POST['other_charges']);
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);
    $status="";
    $balance=0;
   
    $query = "UPDATE invoice SET tenant='$tenant',rent_of='$rent_of',other_charges='$other_charges',amount'$amount',status='$status',balance='$balance' WHERE sno='$id'";
    $query_run = mysqli_query($conn, $query);

  if($query_run)
    {
        $_SESSION['message'] = "Owners Updated Successfully";
        header("Location: invoice.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Owners Not Updated";
        header("Location: invoice.php");
        exit(0);
    }

}

/*
if(isset($_POST['save_student']))
{
    
    $sno = mysqli_num_rows($result);
    $sno++;
    $name_no = mysqli_real_escape_string($conn, $_POST['name_no']);
    $type = mysqli_real_escape_string($conn, $_POST['type']);
    $building = mysqli_real_escape_string($conn, $_POST['building']);
    $floor = mysqli_real_escape_string($conn, $_POST['floor']);
    $rent = mysqli_real_escape_string($conn, $_POST['rent']);
    $electricity_charges = mysqli_real_escape_string($conn, $_POST['electricity_charges']);
    $water_charges = mysqli_real_escape_string($conn, $_POST['water_charges']);
    $garbage_charges = mysqli_real_escape_string($conn, $_POST['garbage_charges']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

   $query = "INSERT INTO house_units (sno,name_no,type,building,floor,rent,electricity_charges,water_charges,garbage_charges,description,status) VALUES ('$sno',$name_no','$type',' $building',' $floor','$rent','$electricity_charges','$water_charges','$garbage_charges','$description','$status')";
  //$query = "  INSERT INTO `house_units` (`sno`, `name_no`, `type`, `building`, `floor`, `rent`, `electricity_charges`, `water_charges`, `garbage_charges`, `description`, `status`) VALUES ('$sno',$name_no','$type',' $building',' $floor','$rent','$electricity_charges','$water_charges','$garbage_charges','$description','$status')";
//INSERT INTO `house_units` (`sno`, `name_no`, `type`, `building`, `floor`, `rent`, `electricity_charges`, `water_charges`, `garbage_charges`, `description`, `status`) VALUES ('3', 'indira', 'multiStorey', 'Dhruv', '4', '10000', '200', '299', '0', 'nikal lode', 'Bhadva hai');
    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: house.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: house.php");
        exit(0);
    }
}*/
if(isset($_POST['save_new']))
{
    $sql1="SELECT rent,electricity_charges,water_charges,garbage_charges FROM house_units";
    $result1 = mysqli_query($conn,$sql1);
  $sno = mysqli_num_rows($result);
    $sno++;
    $tenant = mysqli_real_escape_string($conn, $_POST['name']);
    $rent_of = mysqli_real_escape_string($conn, $_POST['rent_of']);
    $other_charges = mysqli_real_escape_string($conn, $_POST['other_charges']);
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);
    $status="";
    $balance=0;
   

   // $id = mysqli_real_escape_string($conn, $_POST['id']);
  //  $name = mysqli_real_escape_string($conn, $_POST['building_name']);
   // $floors = mysqli_real_escape_string($conn, $_POST['floor']);
 //   $rent = mysqli_real_escape_string($conn, $_POST['rent']);
   // $electricity_charges = mysqli_real_escape_string($conn, $_POST['electricity_charges']);
  /*  $owner = mysqli_real_escape_string($conn, $_POST['owner']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);*/
    $query = "INSERT INTO invoice (sno,rent_of,amount,tenant,balance,status,other_charges) VALUES ('$sno','$rent_of','$amount','$tenant','$balance','$status','$other_charges')";

    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: invoice.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: invoice.php");
        exit(0);
    }
}


?>
