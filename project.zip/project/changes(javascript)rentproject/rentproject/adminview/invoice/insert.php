<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from house_units";
$result = mysqli_query($conn,$sql);
/*
if(isset($_POST['delete_student']))
{
    $id = mysqli_real_escape_string($conn, $_POST['delete_student']);

    $query = "DELETE FROM building_owners WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: bos.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: bos.php");
        exit(0);
    }
}

if(isset($_POST['update_student']))
{
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $agent_percent = mysqli_real_escape_string($conn, $_POST['agent_percent']);
    $date_joined = mysqli_real_escape_string($conn, $_POST['date_joined']);
    $agreement_date = mysqli_real_escape_string($conn, $_POST['agreement_date']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $passport_photo = mysqli_real_escape_string($conn, $_POST['passport_photo']);
    $agreement = mysqli_real_escape_string($conn, $_POST['agreement']);

    $query = "UPDATE building_owners SET name='$name',phone='$phone', email='$email',agent_percent='$agent_percent', date_joined='$date_joined' WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

  if($query_run)
    {
        $_SESSION['message'] = "Owners Updated Successfully";
        header("Location: building_owners.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Owners Not Updated";
        header("Location: building_owners.php");
        exit(0);
    }

}
*/

if(isset($_POST['save_unit']))
{
    
    $sno = mysqli_num_rows($result);
    $sno++;
    $name_no = mysqli_real_escape_string($conn, $_POST['name_no']);
    $type = mysqli_real_escape_string($conn, $_POST['type']);
    $building = mysqli_real_escape_string($conn, $_POST['building']);
    $floor = mysqli_real_escape_string($conn, $_POST['floor']);
    $rent = mysqli_real_escape_string($conn, $_POST['rent']);
    $electricity_charges = mysqli_real_escape_string($conn, $_POST['electricity_charges']);
    $water_charges = mysqli_real_escape_string($conn, $_POST['water_charges']);
    $garbage_charges = mysqli_real_escape_string($conn, $_POST['garbage_charges']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

//    $query = "INSERT INTO house_units (sno,name_no,type,building,floor,rent,electricity_charges,water_charges,garbage_charges,description,status) VALUES ('$sno',$name_no','$type',' $building',' $floor','$rent','$electricity_charges','$water_charges','$garbage_charges','$description','$status')";
  $query = "  INSERT INTO `house_units` (`sno`, `name_no`, `type`, `building`, `floor`, `rent`, `electricity_charges`, `water_charges`, `garbage_charges`, `description`, `status`) VALUES ('$sno',$name_no','$type',' $building',' $floor','$rent','$electricity_charges','$water_charges','$garbage_charges','$description','$status')";
//INSERT INTO `house_units` (`sno`, `name_no`, `type`, `building`, `floor`, `rent`, `electricity_charges`, `water_charges`, `garbage_charges`, `description`, `status`) VALUES ('3', 'indira', 'multiStorey', 'Dhruv', '4', '10000', '200', '299', '0', 'nikal lode', 'Bhadva hai');
    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: house.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: house.php");
        exit(0);
    }
}

?>