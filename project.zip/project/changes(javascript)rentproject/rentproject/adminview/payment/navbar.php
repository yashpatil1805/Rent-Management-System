
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide|Sofia|Trirong&effect=fire|neon|outline|emboss|shadow-multiple">

</head>
<style>
    body{
        background-color:antiquewhite
    }
    div{
        background-color: antiquewhite;
        padding: 0px;
    }
    .view{
        margin-top: 150px;
        padding: 0px;
    }
    table{
        
        width: 1200px;
        height: 150px;

    }
    a{
        text-decoration: none;
    }
    td{
        text-align: center;

    }
    ul{
        
        display: flex;

    }
    li{
        list-style: none;

    }
    .back{
        margin-left: 0px;
        margin-top: 0px;
    }
    .btn{
        margin-left: 0px;
    margin-top: 15px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .new{
        margin-left: 800px;
    
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .search{
        margin-left: 840px;
    margin-top: 15px;
    }
    table.center
    {
        margin-left: auto;
        margin-right: auto;
    }
    
</style>
<body>
    <div class="mydash">
       <ul>
        <li>
        <h2 class="font-effect-shadow-multiple">List Of Payments</h2>
        </li>
        <li>
        <a href="newpage.php" target="dashboard" name="save_unit" class="new">New+</a>
        </li>
       </ul> 

    </div>
    <div class="entries">
       <ul>
        <li>
       

        </li>
        <li class="search">
      <div class="back">  <a href="bos.php" target="bos"> BACK</a></div>
        <form action="search.php" target="bos" method="POST">
        
         Search: <input type="text" name="search">
        
        
       
      
        </form>
        </li>
       </ul> 

    </div>

       
    </table>
</body>
</html>
