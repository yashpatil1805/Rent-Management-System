<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from house_units";
$result = mysqli_query($conn,$sql);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title></title>
    <style>
        body{
            background-color: antiquewhite;
        }
        .card-body {
    flex: 1 1 auto;
    padding: 1rem 1rem;
    background-color: antiquewhite;
}
       
    </style>
</head>
<body>
  
    <div class="container mt-5">

    <a href="active.php" class="btn btn-danger float-end">BACK</a>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">

                        <?php
                        
                                ?>
                                <form action="answer.php" method="POST">
                                <div class="mb-3">
                                        <label>Name</label>
                                        <input type="text" name="name"  class="form-control">
                                    </div>
                                <div class="mb-3">
                                        <label>Phone</label>
                                        <input type="text" name="phone"  class="form-control">
                                    </div>
                                <div class="mb-3">
                                        <label>House Rented</label>
                                        <select name="house_rented" >
                                   <?php  while($row=mysqli_fetch_assoc($result))
                                     { ?>
        <option ><?php echo $row['name_no'].",".$row['type'].",".$row['building'].",".$row['floor']?></option>
        <?php
                                     }  
                                     ?>
                                    </select></div>
                                <div class="mb-3">
                                        <label>Date Occupied</label>
                                        <input type="date" name="date_occupied"  class="form-control">
                                    </div>
                                <div class="mb-3">
                                        <label>Id No.</label>
                                        <input type="text" name="id_no"  class="form-control">
                                    </div>
                                <div class="mb-3">
                                        <label>Email</label>
                                        <input type="email" name="email"  class="form-control">
                                    </div>
                                <div class="mb-3">
                                        <label>Upload Passport Photo</label>
                                        <input type="file" name="download_photo"  class="form-control">
                                    </div>
                                <div class="mb-3">
                                        <label>Upload Agreement Document</label>
                                        <input type="file" name="agreement_doc"  class="form-control">
                                    </div>
                               
                                    
                             

                                       
                                    <div class="mb-3">
                                        <button type="submit" name="save_new" class="btn btn-primary">
                                            Save Unit
                                        </button>
                                        
                                    </div>

                                </form>
                                <?php
                            
                           
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>
</html>