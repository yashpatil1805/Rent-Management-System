<?php
$conn=mysqli_connect("localhost","root","","rentdb");
$sql="SELECT * from house_repairs";
$result = mysqli_query($conn,$sql);
$bu="SELECT name_no from house_units";
$result1 = mysqli_query($conn,$bu);
$unit="SELECT type from unittype";
$result2 = mysqli_query($conn,$unit);
$floors="SELECT floors from building";
$result3 = mysqli_query($conn,$floors);


/*if(mysqli_num_rows($result1) > 0)  
{
    $building[] = array();
    while($buil=$result1->fetch_assoc())         
    {
        $building[] = $buil;      
    }
}
else
{
    echo "NO products found";
}*/
//$b="SELECT * from house_units";
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Edit House repairs</title>
    <style>
           .card-body {
    flex: 1 1 auto;
    padding: 1rem 1rem;
    background-color: antiquewhite;
}
       body{
        background-color: antiquewhite;
       }
    </style>
</head>
<body>
  
    <div class="container mt-5">

       

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4> Edit House repairs
                            <a href="house.php" class="btn btn-danger float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <?php
                      /*  $b=$_GET['sno'];
                        echo $b;*/
                     if(isset($_GET['sno']))
                     {
                         $b_id = mysqli_real_escape_string($conn, $_GET['sno']);
                         $query = "SELECT * FROM house_repairs WHERE sno='$b_id' ";
                         $query_run = mysqli_query($conn, $query);
                    /*    $a=mysqli_num_rows($query_run);
                        echo $a;*/
                         if(mysqli_num_rows($query_run) > 0)
                         {
                             $unit = mysqli_fetch_array($query_run);
                             ?>
                             <form action="answer.php" method="POST">
                                  <input type="hidden" name="sno" value="<?= $unit['sno']; ?>">
                                  <div class="mb-3">
                                     <label>Unit name</label>
                                     <select name="name_no" >
                                   <?php  while($row=mysqli_fetch_assoc($result1))
                                     { ?>
        <option ><?php echo $row['name_no'] ?></option>
        <?php
                                     }  
                                     ?>
                                    </select>    </div>
                                    <div class="mb-3">
                                     <label>Tenants to be charged</label>
                                     <input type="text" name="tt" value="<?= $unit['tenant_to_be_charged']; ?>" class="form-control">
                                     </div>
                                    <div class="mb-3">
                                        <label>Date</label>
                                        <input type="date" name="date"  value="<?= $unit['date']; ?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Total cost</label>
                                        <input type="text" name="cost" value="<?= $unit['total_cost']; ?>"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Description</label>
                                        <input type="text" name="description" value="<?= $unit['description']; ?>"  class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <button type="submit" name="update_rec" class="btn btn-primary">
                                            Save 
                                        </button>
                                        
                                    </div>

                             </form>
                               
                        <?php
                         }
                          ?> 
                             <?php
                         }
                         else
                         {
                             echo "<h4>No Such Id Found</h4>";
                         }
                     
                     ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>