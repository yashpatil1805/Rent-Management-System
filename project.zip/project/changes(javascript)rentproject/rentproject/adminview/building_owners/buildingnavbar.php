
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide|Sofia|Trirong">
</head>
<style>
    body{
        background-color:antiquewhite;
        /* font-family: "Trirong", sans-serif; */
    }
    div{
        background-color: antiquewhite;
        padding: 0px;
    }
    .view{
        margin-top: 150px;
        padding: 0px;
    }
    table{
        width: 1200px;
        height: 150px;

    }
    a{
        text-decoration: none;
    }
    td{
        text-align: center;

    }
    ul{
        display: flex;
        margin-top: 15px;
    }
    li{
        list-style: none;

    }
    .back{
        transform:translate(150px,-102px);
        margin-left: 0px;
        margin-top: 0px;
        padding: 10px;
        width:40px;
        background-image: linear-gradient(45deg,#d7af87,white);
    border-radius: 20px;
    }
    .btn{
        margin-left: 0px;
    margin-top: 15px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(rgb(100, 203, 68),rgb(72, 105, 169));
    }
    .new{
    transform:translate(50px,-50px);
    margin-left: 670px;
    padding: 10px;
    border:none;
    background-image: linear-gradient(45deg,#d7af87,white);
    border-radius: 20px;  
    
}
    .search{
        margin-left: 840px;
    margin-top: 10px;
    }
    table.center
    {
        margin-left: auto;
        margin-right: auto;
    }
    input{
        border-radius: 20px;
        background-color: silver;
    }
    select{
        border-radius: 20px;
    }
</style>
<body>
    <div class="mydash">
       <ul>
        <li>
        <h2 class="font-effect-shadow-multiple">List Of Building Owners</h2>
        <!-- <h2 class="font-effect-outline">List Of Building Owners</h2>
        <h2 class="font-effect-emboss">List Of Building Owners</h2>
        <h2 class="font-effect-shadow-multiple">List Of Building Owners</h2>-->
        </li>
        <li>
        <a href="building_owners_new.php?" target="dashboard" class="new">New+</a>
        </li>
       </ul> 

    </div>
    <div class="entries">
       <ul>
        <li>
        


        </li>
        <li class="search">
      <div class="back">  <a href="bos.php" target="bos"> BACK</a></div>
        <form action="search.php" target="bos" method="POST">
        
         Search: <input type="text" name="search">
        
        
       
      
        </form>
        </li>
       </ul> 

    </div>
   
    
        <?php
      /*  $key=$_POST["search"];
    
        $conn=mysqli_connect("localhost","root","","rentdb");
        $sql="SELECT * from building_owners";
        $result=mysqli_query($conn,$sql);

    
            while($row=mysqli_fetch_assoc($result))
            {
                if($key == ($row['id'] or $row['name']))
               {
                    echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
                }
                else{
                    echo "person not found";
                }
            }*/
        /*    $uid=$_POST['search'];
            $conn=mysqli_connect("localhost","root","","rentdb");
            $sql="SELECT * from building_owners";
            $result = mysqli_query($conn,$sql);
            while($row=mysqli_fetch_assoc($result))
            {
                if($uid == $row['id'])
                {
                    echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
                }
            } */
            
        //   while($row=$result->fetch_assoc()){
          //      echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
              
          //}
       //   $uid=$_POST['search'];
           
          
         /*   while($row=mysqli_fetch_assoc($result))
            {
                if($uid == $row['id'])
                {
                    echo"<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["phone"]."</td><td>". $row["email"]."</td><td>". $row["agent_percent"]."</td><td>". $row["date_joined"]."</td></tr>";
                }
            }   */
        
        ?>
       
    </table>
</body>
</html>
