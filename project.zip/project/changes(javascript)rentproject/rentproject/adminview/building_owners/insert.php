<?php
$conn=mysqli_connect("localhost","root","","rentdb");


if(isset($_POST['delete_student']))
{
    $id = mysqli_real_escape_string($conn, $_POST['delete_student']);

    $query = "DELETE FROM building_owners WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    $query1 = "SELECT * FROM building";
    $query_run1 = mysqli_query($conn, $query1);
    
    while($row=$query_run1->fetch_assoc())
        {
            if($row['owner_id']==$id)
            {
                $query2 = "DELETE FROM building WHERE owner_id='$id' ";
                $query_run2 = mysqli_query($conn, $query2);
            }
        }

        $query3 = "SELECT * FROM unittype";
        $query_run3 = mysqli_query($conn, $query3);
       
        
       
        while($row1=$query_run3->fetch_assoc())
        {
         
          
            if($row1['ownerid']==$id)
            {
            $query4 = "DELETE FROM unittype WHERE ownerid='$id' ";
            $query_run4 = mysqli_query($conn, $query4);
                
            }
        }


    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: bos.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: bos.php");
        exit(0);
    }

    if($query_run2)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: bos.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: bos.php");
        exit(0);
    }
}

if(isset($_POST['update_student']))
{
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $agent_percent = mysqli_real_escape_string($conn, $_POST['agent_percent']);
    $date_joined = mysqli_real_escape_string($conn, $_POST['date_joined']);
    $agreement_date = mysqli_real_escape_string($conn, $_POST['agreement_date']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $passport_photo = mysqli_real_escape_string($conn, $_POST['passport_photo']);
    $agreement = mysqli_real_escape_string($conn, $_POST['agreement']);

    $query = "UPDATE building_owners SET name='$name',phone='$phone', email='$email',agent_percent='$agent_percent', date_joined='$date_joined' WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

  if($query_run)
    {
        $_SESSION['message'] = "Owners Updated Successfully";
        header("Location: building_owners.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Owners Not Updated";
        header("Location: building_owners.php");
        exit(0);
    }

}


if(isset($_POST['save_student']))
{

    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $agent_percent = mysqli_real_escape_string($conn, $_POST['agent_percent']);
    $date_joined = mysqli_real_escape_string($conn, $_POST['date_joined']);
    $agreement_date = mysqli_real_escape_string($conn, $_POST['agreement_date']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $passport_photo = mysqli_real_escape_string($conn, $_POST['passport_photo']);
    $agreement = mysqli_real_escape_string($conn, $_POST['agreement']);

    $query = "INSERT INTO building_owners (id,name,phone,email,agent_percent,date_joined,agreement_date,status,passport_photo,agreement) VALUES ('$id','$name','$phone','$email','$agent_percent','$date_joined','$agreement_date','$status','$passport_photo','$agreement')";

    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Owner Created Successfully";
        header("Location: building_owners.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: building_owners.php");
        exit(0);
    }
}

?>